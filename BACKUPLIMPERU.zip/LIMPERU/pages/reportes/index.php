

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
          <div class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                  <i class="fa fa-bell me-lg-2"></i>
                  <span class="d-none d-lg-inline-flex">Notificaciones</span>
              </a>
              <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                  <hr class="dropdown-divider">
                  <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
              </div>
          </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex">John Doe</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->


    <script type="text/javascript">
    $("#salir").click(function(){
      swal({
           title: "Cerrar Sesion",
           text: "Realmente deseas salir de la sesion actual ?",
           type: "warning",
           showCancelButton: true,
           confirmButtonColor: "#034b7b",
           confirmButtonText: "Aceptar",
           cancelButtonText: "Cancelar",
           closeOnConfirm: false,
           closeOnCancel: false
          },
          function(isConfirm){
           if (isConfirm) {
             $.ajax({
                 url:'pages/admin/logout.php',
                 type:'post',
                 success:function(response){
                   window.location="index.php";
                 }
             });
           } else {
              swal.close();
           }
        });
    });
    </script>


    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Porcentaje de Cumplimiento</h6>
                    <canvas id="line-chart"></canvas>
                </div>
            </div>
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Procesos</h6>
                    <canvas id="pie-chart"></canvas>
                </div>
            </div>
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Doughnut Chart</h6>
                    <canvas id="doughnut-chart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
    // Worldwide Sales Chart

    // Single Line Chart
    var ctx3 = $("#line-chart").get(0).getContext("2d");
    var myChart3 = new Chart(ctx3, {
        type: "line",
        data: {
            labels: ["Ene", "Feb", "Mar", "Abr", "May", 100, 110, 120, 130, 140, 150],
            datasets: [{
                label: "Salse",
                fill: false,
                backgroundColor: "rgba(0, 156, 255, .3)",
                data: [7, 8, 8, 9, 9, 9, 10, 11, 14, 14, 15]
            }]
        },
        options: {
            responsive: true
        }
    });




    // Pie Chart
    var ctx5 = $("#pie-chart").get(0).getContext("2d");
    var myChart5 = new Chart(ctx5, {
        type: "pie",
        data: {
            labels: ["Abierta", "No realizada", "En Proceso", "Cancelada", "Finalizada"],
            datasets: [{
                backgroundColor: [
                    "rgba(0, 156, 255, .7)",
                    "rgba(0, 156, 255, .6)",
                    "rgba(0, 156, 255, .5)",
                    "rgba(0, 156, 255, .4)",
                    "rgba(0, 156, 255, .3)"
                ],
                data: [0, 9, 2, 4, 105]
            }]
        },
        options: {
            responsive: true
        }
    });


    // Doughnut Chart
    var ctx6 = $("#doughnut-chart").get(0).getContext("2d");
    var myChart6 = new Chart(ctx6, {
        type: "doughnut",
        data: {
            labels: ["Italy", "France", "Spain", "USA", "Argentina"],
            datasets: [{
                backgroundColor: [
                    "rgba(0, 156, 255, .7)",
                    "rgba(0, 156, 255, .6)",
                    "rgba(0, 156, 255, .5)",
                    "rgba(0, 156, 255, .4)",
                    "rgba(0, 156, 255, .3)"
                ],
                data: [55, 49, 44, 24, 15]
            }]
        },
        options: {
            responsive: true
        }
    });

    </script>
    <!-- Footer Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
LIMPERU-SERVICIOS DE LIMPIEZA Y MANTENIMIENTO DEL PERU
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
