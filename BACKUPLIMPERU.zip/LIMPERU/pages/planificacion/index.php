
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
          <div class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                  <i class="fa fa-bell me-lg-2"></i>
                  <span class="d-none d-lg-inline-flex">Notificaciones</span>
              </a>
              <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                  <hr class="dropdown-divider">
                  <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
              </div>
          </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex">John Doe</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->


    <script type="text/javascript">
    $("#salir").click(function(){
      swal({
           title: "Cerrar Sesion",
           text: "Realmente deseas salir de la sesion actual ?",
           type: "warning",
           showCancelButton: true,
           confirmButtonColor: "#034b7b",
           confirmButtonText: "Aceptar",
           cancelButtonText: "Cancelar",
           closeOnConfirm: false,
           closeOnCancel: false
          },
          function(isConfirm){
           if (isConfirm) {
             $.ajax({
                 url:'pages/admin/logout.php',
                 type:'post',
                 success:function(response){
                   window.location="index.php";
                 }
             });
           } else {
              swal.close();
           }
        });
    });
    </script>



    <!-- Recent Sales Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Historial</h6>
          <!--      <button type="button" id="addPlanificacion" class="btn btn-primary m-2">
                  <i class="fa fa-plus me-2"></i>
                  Agregar Planificacion</button>-->
            </div>
            <script type="text/javascript">
              $('#addPlanificacion').click(function(){
                funcionajax("pages/planificacion/addForm.php","container","");
              });
            </script>


            <div class="table-responsive">
               
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                          <th scope="col"><input class="form-check-input" type="checkbox"></th>
                          <th scope="col">Fecha Ejecucion</th>
                          <th scope="col">Titulo</th>
                          <th scope="col">Descripcion</th>
                          <th scope="col">Operador</th>
                          <th scope="col">Finalizado</th>
                          <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                      <tr>
                          <td colspan="7" style="text-align:center;">No hay registros</td>
                      </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Recent Sales End -->



    <!-- Widgets End -->


    <!-- Footer Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
LIMPERU-SERVICIOS DE LIMPIEZA Y MANTENIMIENTO DEL PERU
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
