
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
          <div class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                  <i class="fa fa-bell me-lg-2"></i>
                  <span class="d-none d-lg-inline-flex">Notificaciones</span>
              </a>
              <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                  <hr class="dropdown-divider">
                  <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
              </div>
          </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex">John Doe</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->

    <script type="text/javascript">
    $("#salir").click(function(){
      swal({
           title: "Cerrar Sesion",
           text: "Realmente deseas salir de la sesion actual ?",
           type: "warning",
           showCancelButton: true,
           confirmButtonColor: "#034b7b",
           confirmButtonText: "Aceptar",
           cancelButtonText: "Cancelar",
           closeOnConfirm: false,
           closeOnCancel: false
          },
          function(isConfirm){
           if (isConfirm) {
             $.ajax({
                 url:'pages/admin/logout.php',
                 type:'post',
                 success:function(response){
                   window.location="index.php";
                 }
             });
           } else {
              swal.close();
           }
        });
    });
    </script>



    <!-- Recent Sales Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Operarios</h6>
                <button type="button" id="addOperario" class="btn btn-primary m-2">
                  <i class="fa fa-plus me-2"></i>Agregar Operario</button>
            </div>

            <script type="text/javascript">
              $('#addOperario').click(function(){
                funcionajax("pages/operadores/addForm.php","container","");
              });
            </script>


            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col"><input class="form-check-input" type="checkbox"></th>
                            <th scope="col">Id</th>
                            <th scope="col">Foto</th>
                            <th scope="col">Identificacion</th>
                            <th scope="col">Nombre(s)</th>
                            <th scope="col">Apellido(s)</th>
                            <th scope="col">Estado</th>
                            <th scope="col" style="text-align:center;">Accion</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php
                       require "../../class/db/clsController.php";
                       $obj_cnsc = new clsCnsc();
                       $resultado_cnsc = $obj_cnsc->ConsultarOperario();
                        if(mysqli_num_rows($resultado_cnsc)>0){
                          $cont = 0;
                             while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                              $cont++;
                            ?>
                              <tr class="dato">
                                <td><input class="form-check-input" type="checkbox"></td>
                                <td><?php echo $cont; ?></td>
                                <td><img src="img/photo1.png" class="border-radius-100 shadow" width="40" height="40" alt=""></td>
                                <td><?php echo $listar_repuesto["identificacion"]; ?></td>
                                <td><?php echo $listar_repuesto["nombre"]; ?></td>
                                <td><?php echo $listar_repuesto["apellido"]; ?></td>
                                <td><?php echo $listar_repuesto["estado"]; ?></td>
                                <td style="text-align:center;">
                                  <div class="btn-group">
                                    <button type="button"  atrib="<?php echo $listar_repuesto['id']; ?>" class="eliminar btn btn-danger btn-sm eliminar"><i class="fa fa-trash" aria-hidden="true"></i> Eliminar</button>
                                    <button type="button"  atrib="<?php echo $listar_repuesto['id']; ?>" style="color:#fff;"  class="editar btn btn-warning btn-sm editar"><i class="fa fa-pencil" aria-hidden="true"></i> Editar</button>
                                  </div>
                                </td>
                              </tr>
                              <?php
                               }
                             }else{
                              ?>
                              <tr>
                                  <td colspan="9" style="text-align:center;">No se encontraron registros</td>
                              </tr>
                          <?php
                            }
                          ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Recent Sales End -->
  <script type="text/javascript">
  $(".eliminar").click(function(){
    var a = $(this).attr("atrib");
    var parametros = {
        "valorCaja1" : a
    };
    $.ajax({
       url : 'pages/operadores/eliminar.php',
       data:  parametros,
       type: "post",
       success : function(response) {
           funcionajax("pages/operadores/index.php","container","");
       },
       error : function(xhr, status) {
           funcionajax("pages/operadores/index.php","container","");
       },
       complete : function(xhr, status) {
       }
    });
  });



    $(".editar").click(function(){
      var a = $(this).attr('atrib');
      funcionajax("pages/operadores/editForm.php","container",a);
    });
  </script>


    <!-- Widgets End -->


    <!-- Footer Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
LIMPERU-SERVICIOS DE LIMPIEZA Y MANTENIMIENTO DEL PERU
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
