  <?php
    header("Cache-Control: no-store, no-cache, must-revalidate");
    require "../../class/db/clsController.php";
    $obj_mantenimiento = new clsCnsc();
    $resultado = $obj_mantenimiento->ConsultarIdZona($_POST['id']);
    $listar = mysqli_fetch_assoc($resultado);
  ?>

    <link rel="stylesheet" href="css/img/bootstrap.min.css">
    <script src="js/jquery-validation-1.14.0/dist/jquery.validate.js"></script>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa fa-bell me-lg-2"></i>
                    <span class="d-none d-lg-inline-flex">Notificatin</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <a href="#" class="dropdown-item">
                        <h6 class="fw-normal mb-0">Profile updated</h6>
                        <small>15 minutes ago</small>
                    </a>
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item">
                        <h6 class="fw-normal mb-0">New user added</h6>
                        <small>15 minutes ago</small>
                    </a>
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item">
                        <h6 class="fw-normal mb-0">Password changed</h6>
                        <small>15 minutes ago</small>
                    </a>
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item text-center">See all notifications</a>
                </div>
            </div>





            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex">John Doe</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <a href="#" class="dropdown-item">My Profile</a>
                    <a href="#" class="dropdown-item">Settings</a>
                    <a href="#" class="dropdown-item">Log Out</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->


    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-6 col-xl12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Formulario Agregar Nuevo Zona</h6>
                    <form id="AddFormZona">
                        <div class="mb-3">
                          <button type="button" class="btn btn-primary row" data-toggle="modal" data-target="#exampleModal">
                            Mostrar Mapa
                          </button>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Id de la Zona</label>
                            <input type="text" value="<?php echo $listar['id']; ?>" readonly class="form-control" id="idinputzona" name="idinputzona">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Nombre de la Zona</label>
                            <input type="text" value="<?php echo $listar['zona']; ?>" class="form-control" id="inputNombre" name="inputNombre">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Marcador</label>
                            <textarea class="form-control"   id="inputMarcador" name="inputMarcador" rows="7"><?php echo $listar['area']; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Estado</label>
                            <select class="form-select mb-3"  id="slcEstado" name="slcEstado">
                                <option selected>Seleccione un estado</option>
                                <option <?php if($listar['estado'] == "activo"){ echo "selected";} ?> value="activo">Activo</option>
                                <option <?php if($listar['estado'] == "inactivo"){ echo "selected";} ?> value="inactivo">Inactivo</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Guardar Datos</button>
                    </form>
                    <script type="text/javascript">
                    $("#AddFormZona").validate({ debug: true,
                      rules:{
                        inputNombre:{required: true},
                        inputMarcador:{required: true},
                        slcEstado:{required: true}
                      },
                      messages:{
                        inputNombre:{required: "<span class='label label-danger'>Ingrese un nombre</span>"},
                        inputMarcador:{required: "<span class='label label-danger'>Ingrese una marcacion</span>"},
                        slcEstado:{required: "<span class='label label-danger'>Seleccione un estado</span>"}
                      },
                      submitHandler: function(form){
                        guardarForm("pages/zonas/crearZonas.php", "AddFormZona", function(resultado){
                        if (resultado == "err:ok") {
                            funcionajax("pages/zonas/index.php","container","");
                          }
                        });
                        }
                      });
                    </script>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
                    Software para gestion de tareas Limperu</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
