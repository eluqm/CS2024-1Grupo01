package com.example.notificacionesfcm.modelo;

public class Asignacion{
    public static final String TABLE_NAME = "Asignacion";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_FECHA = "fecha";
    public static final String COLUMN_TITULO = "titulo";
    public static final String COLUMN_DESCRIPCION = "descripcion";
    public static final String COLUMN_ZONA = "zona";

    public static final String COLUMN_FKZONA = "fkzona";

    public static final String COLUMN_OPERARIO = "operario";
    public static final String COLUMN_ESTADO = "estado";
    public static final String COLUMN_FOTO = "foto";
    public static final String COLUMN_REPORTE = "reporte";


    private int id;
    private String fecha;
    private String titulo;
    private String descripcion;
    private String zona;
    private String fkzona;
    private String operario;
    private String estado;
    private String foto;
    private String reporte;


    public Asignacion() {
    }

    public Asignacion(int id, String  fecha, String titulo,String descripcion,
    String zona, String fkzona, String operario, String estado,
    String foto, String reporte
    ) {
        this.id = id;
        this.fecha = fecha;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fkzona = fkzona;
        this.zona = zona;
        this.operario = operario;
        this.estado = estado;
        this.foto = foto;
        this.reporte = reporte;
    }

    public void setId(int id) {
    this.id = id;
    }
    public int getId() {
    return id;
    }

    public void setFecha(String fecha) {
    this.fecha = fecha;
    }
    public String getFecha() {
    return fecha;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getTitulo() {
        return titulo;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public String getDescripcion() {
        return descripcion;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }
    public String getZona() {
        return zona;
    }



    public void setFkZona(String fkzona) {
        this.fkzona = fkzona;
    }
    public String getFkZona() {
        return fkzona;
    }


    public void setOperario(String operario) {
        this.operario = operario;
    }
    public String getOperario() {
        return operario;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    public String getEstado() {
        return estado;
    }


    public void setFoto(String foto) {
        this.foto = foto;
    }
    public String getFoto() {
        return foto;
    }

    public void setReporte(String reporte) {
        this.reporte = reporte;
    }
    public String getReporte() {
        return reporte;
    }
}
