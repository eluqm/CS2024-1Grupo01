package com.example.notificacionesfcm;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.notificacionesfcm.adaptador.AsignacionAdapter;
import com.example.notificacionesfcm.modelo.Asignacion;
import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.Permission;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class ListadoActivity extends AppCompatActivity {

    private ProgressDialog pDialog;
    private List<Asignacion> listAnimation = new ArrayList<>();
    private RecyclerView recyclerView;
    private AsignacionAdapter myadapter;
    String path = GlobalInfo.PATH_IP;

    public static final String sid = "idKey";
    public static final String sfoto = "fotoKey";
    public static final String sidentificacion = "identificacionKey";
    public static final String snombre = "nombreKey";
    public static final String sapellido = "apellidoKey";
    public static final String susuario = "usuarioKey";
    public static final String scorreo = "correoKey";
    public static final String stelefono = "telefonoKey";
    public static final String sestado = "estadoKey";
    public static final String MY_PREFS_NAME = "MySession";
    SharedPreferences.Editor editor;


    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set portrait orientation
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_listado);

        editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();

        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));

        AndPermission
                .with(this)
                .permission(Permission.READ_EXTERNAL_STORAGE, Permission.WRITE_EXTERNAL_STORAGE)
                .onDenied(new Action() {
                    @Override
                    public void onAction(List<String> permissions) {

                    }
                })
                .start();

        SharedPreferences shared = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String idch = (shared.getString(sid, ""));

      //  Toast.makeText(ListadoActivity.this, "id " + idch, Toast.LENGTH_LONG).show();

/*
        linear1 = findViewById(R.id.linear1);
        linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ListadoActivity.this, MainActivity.class );
                startActivity(intent);
            }
        });
        linear2 = findViewById(R.id.linear2);
        linear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ListadoActivity.this, MainActivity.class );
                startActivity(intent);
            }
        });*/

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        recyclerView = findViewById(R.id.recycler_fijo);
        CargarData(idch);
    }





    private void CargarData(final String sid) {
        String tag_string_req = "req_register";
        pDialog.setMessage("Cargando ...");
        showDialog();
        StringRequest strReq = new StringRequest(Request.Method.POST,
                path+"listadoid.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                hideDialog();
                  try {
                    JSONArray myJsonArray = new JSONArray(response);
                    for (int i = 0; i < myJsonArray.length(); i++) {
                        Asignacion ob = new Asignacion();
                        ob.setId(myJsonArray.getJSONObject(i).getInt("id"));
                        ob.setFecha(myJsonArray.getJSONObject(i).getString("fecha"));
                        ob.setTitulo(myJsonArray.getJSONObject(i).getString("titulo"));
                        ob.setDescripcion(myJsonArray.getJSONObject(i).getString("descripcion"));
                        ob.setZona(myJsonArray.getJSONObject(i).getString("zona"));
                        ob.setFkZona(myJsonArray.getJSONObject(i).getString("fkzona"));
                        ob.setOperario(myJsonArray.getJSONObject(i).getString("operario"));
                        ob.setEstado(myJsonArray.getJSONObject(i).getString("estado"));
                        ob.setFoto(myJsonArray.getJSONObject(i).getString("foto"));
                        ob.setReporte(myJsonArray.getJSONObject(i).getString("reporte"));

                        listAnimation.add(ob);
                    }
                    setupRecyclerView(listAnimation);
                 } catch (JSONException e) {
                     e.printStackTrace();
                 }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                hideDialog();
                Toast.makeText(getApplicationContext(), "error: " +error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", sid);
                return params;
            }
        };
        AppCore.getInstance().addToRequestQueue(strReq, tag_string_req);
    }


    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    private void setupRecyclerView(List<Asignacion> listAnimation) {
        myadapter = new AsignacionAdapter(this, listAnimation);
        int numItems = myadapter.getItemCount();
        if (numItems == 0) {
            recyclerView.setVisibility(View.GONE);
            // linear1.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setAdapter(myadapter);
            recyclerView.setVisibility(View.VISIBLE);
            // linear1.setVisibility(View.GONE);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            editor.clear().apply();
            Intent intent = new Intent(ListadoActivity.this, LoginActivity.class );
            startActivity(intent);
        }
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }


}
