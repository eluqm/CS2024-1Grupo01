package com.example.notificacionesfcm.adaptador;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.notificacionesfcm.MainActivity;
import com.example.notificacionesfcm.R;
import com.example.notificacionesfcm.modelo.Asignacion;
import java.util.ArrayList;
import java.util.List;

public class AsignacionAdapter extends RecyclerView.Adapter<AsignacionAdapter.MyViewHolder> implements Filterable {
    private Context context;
    private List<Asignacion> notesList;
    private List<Asignacion> movieListFiltered;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView fecha;
        public TextView titulo;
        public TextView descripcion;
        public TextView estado;
        public LinearLayout linear1;

        public MyViewHolder(View view) {
            super(view);
             fecha = view.findViewById(R.id.fecha);
             titulo = view.findViewById(R.id.list_titulo);
             descripcion = view.findViewById(R.id.list_descripcion);
             estado = view.findViewById(R.id.list_estado);
             linear1 = view.findViewById(R.id.linear1);
        }
    }


    public AsignacionAdapter(Context context, List<Asignacion> notesList) {
        this.context = context;
        this.notesList = notesList;
        this.movieListFiltered = notesList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.asignacion_list_layout, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        final Asignacion note = notesList.get(position);
        holder.fecha.setText(""+note.getFecha());
        holder.titulo.setText(""+note.getTitulo());
        holder.descripcion.setText(""+note.getDescripcion());
        holder.estado.setText(""+note.getEstado());
      //  holder.telefono.setText(""+note.getTelefono());

        holder.linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MainActivity.class);
                intent.putExtra("id",""+note.getId());
                intent.putExtra("fecha",""+note.getFecha());
                intent.putExtra("titulo",""+note.getTitulo());
                intent.putExtra("descripcion",""+note.getDescripcion());
                intent.putExtra("fkzona",""+note.getFkZona());
                intent.putExtra("zona",""+note.getZona());
                intent.putExtra("operario",""+note.getOperario());
                intent.putExtra("estado",""+note.getEstado());
                intent.putExtra("foto",""+note.getFoto());
                intent.putExtra("reporte",""+note.getReporte());
                context.startActivity(intent);
            }
        });
        /*
        File imgFile = new File(note.getFoto());
        Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
        holder.dot.setImageBitmap(myBitmap);*/
    }

    private void EliminarProducto(int id, int position) {
      //  mDatabase.deleteProducto(id);
        notesList.remove(position);
        this.notifyItemRemoved(position);
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    notesList = movieListFiltered;
                } else {
                    List<Asignacion> filteredList = new ArrayList<>();
                    for (Asignacion movie : notesList) {
                        if (movie.getTitulo().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(movie);
                         //   Log.e(" moview tet rre"," Cliente "+movie.getNombre()+" "+movie.getNombre().toString());
                        }
                    }
                    notesList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = notesList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                notesList = (ArrayList<Asignacion>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @Override
    public int getItemCount() {
        return notesList.size();
    }

}
