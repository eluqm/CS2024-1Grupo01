package com.example.notificacionesfcm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.snackbar.Snackbar;
import android.widget.Button;
import android.widget.EditText;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
import static android.content.Context.MODE_PRIVATE;

public class LoginActivity extends Activity {

    private Button boton;
    private TextView texto;
    private ProgressDialog pDialog;
    private EditText ausuario;
    private EditText acontrasena;
    public static final String sid = "idKey";
    public static final String sfoto = "fotoKey";
    public static final String sidentificacion = "identificacionKey";
    public static final String snombre = "nombreKey";
    public static final String sapellido = "apellidoKey";
    public static final String susuario = "usuarioKey";
    public static final String scorreo = "correoKey";
    public static final String stelefono = "telefonoKey";
    public static final String sestado = "estadoKey";
    public static final String MY_PREFS_NAME = "MySession";
    SharedPreferences.Editor editor;
    SharedPreferences openeditor;
    String path = GlobalInfo.PATH_IP;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));

         openeditor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
         if(openeditor.contains(susuario) && openeditor.contains(sid)){
             Intent intent = new Intent( LoginActivity.this,ListadoActivity.class );
             startActivity(intent);
         }

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        ausuario = findViewById(R.id.editTextUserName);
        acontrasena = findViewById(R.id.editTextPassword);

        boton = findViewById(R.id.btn_login);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*
                Intent intent = new Intent( LoginActivity.this,ListadoActivity.class );
                startActivity(intent);*/
                LoginUser(ausuario, acontrasena);
            }
        });
    }


    public void LoginUser(EditText nombre, EditText contrasena) {
        String xnombre = nombre.getText().toString();
        String xcontrasena = contrasena.getText().toString();

        if (!xnombre.isEmpty() && !xcontrasena.isEmpty()) {
            ValidarUser(xnombre, xcontrasena);
        } else {
           if(acontrasena.getText().toString().equals("")){
               acontrasena.setError("El campo no puede estar en blanco");
           }
           if(ausuario.getText().toString().equals("")){
               ausuario.setError("El campo no puede estar en blanco");
           }
        }
    }

    private void ValidarUser(final String suser, final String scontrasena) {
      String tag_string_req = "req_register";
      pDialog.setMessage("Validando usuario ...");
      showDialog();
      StringRequest strReq = new StringRequest(Request.Method.POST,
               path+"login.php", new Response.Listener<String>() {
          @Override
          public void onResponse(String response) {
              hideDialog();
              if(response.equals("[]")){
                  Toast.makeText(LoginActivity.this, "Usuario o contraseÃ±a no validos", Toast.LENGTH_LONG).show();
              } else {
                  try {
                      JSONArray respObj = new JSONArray(response);
                      for (int i = 0; i < respObj.length(); i++) {
                          JSONObject c = respObj.getJSONObject(i);
                          String resultado = c.getString("resultado");
                          String id =  c.getString("id");
                          String foto = c.getString("foto");
                          String identificacion = c.getString("identificacion");
                          String nombre = c.getString("nombre");
                          String apellido = c.getString("apellido");
                          String correo = c.getString("correo");
                          String telefono = c.getString("telefono");
                          String usuario = c.getString("usuario");
                          String estado = c.getString("estado");

                          if (resultado.equals("1")) {
                              editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                              editor.putString(sid, id);
                              editor.putString(sfoto, foto);
                              editor.putString(sidentificacion, identificacion);
                              editor.putString(susuario, usuario);
                              editor.putString(snombre, nombre);
                              editor.putString(sapellido, apellido);
                              editor.putString(scorreo, correo);
                              editor.putString(stelefono, telefono);
                              editor.putString(sestado, estado);
                              editor.commit();

                              Intent intent = new Intent(LoginActivity.this,ListadoActivity.class);
                              startActivity(intent);
                              finish();
                          }
                          if (resultado.equals("0")) {
                              Toast.makeText(LoginActivity.this, "Usuario o contraseÃ±a no validos", Toast.LENGTH_LONG).show();
                          }
                          if (resultado.equals("2")) {
                              Toast.makeText(LoginActivity.this, "Campos no pueden estar vacios", Toast.LENGTH_LONG).show();
                          }
                      }

                  ausuario.setText("");
                  acontrasena.setText("");
              } catch (JSONException e) {
                  e.printStackTrace();
                  Toast.makeText(getApplicationContext(), "e: " +e.getMessage(), Toast.LENGTH_LONG).show();
              }
            }
          }
      }, new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError error) {
              hideDialog();
              Toast.makeText(getApplicationContext(), "error: " +error.getMessage(), Toast.LENGTH_LONG).show();
          }
      }) {
          @Override
          protected Map<String, String> getParams() {
              Map<String, String> params = new HashMap<String, String>();
              params.put("usuario", suser);
              params.put("clave",scontrasena);
              return params;
          }
      };
      AppCore.getInstance().addToRequestQueue(strReq, tag_string_req);
  }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }


    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        Intent intent = new Intent(LoginActivity.this,
               SplashActivity.class);
        startActivity(intent);
        finish();
    }
}
