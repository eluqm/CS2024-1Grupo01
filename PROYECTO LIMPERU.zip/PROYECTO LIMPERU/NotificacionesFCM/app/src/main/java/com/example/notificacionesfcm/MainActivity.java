package com.example.notificacionesfcm;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.Manifest;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.Permission;
import org.json.JSONArray;
import org.json.JSONObject;
import cn.pedant.SweetAlert.SweetAlertDialog;


public class MainActivity extends AppCompatActivity {

    int ids;
    String xid, xzona ,xtitulo, xdescripcion , xestado, xreporte, xfoto;
    String fechas, titulos, descripcions, zonas, fkzonas,  operarios, estados, esfoto, esreporte;
    private EditText edttitulo, edtdescripcion, edtzona;
    TextView txtestado;
    ImageView imagen, foto;
    String path;

    private final String CARPETA_RAIZ="misImagenesPrueba/";
    private final String RUTA_IMAGEN=CARPETA_RAIZ+"misFotos";
    final int COD_SELECCIONA=10;
    final int COD_FOTO=20;
    private static final int MY_PERMISSIONS_REQUEST_CAMARA = 0;
    private EditText edtidActividad;
    private Button sbButton;
    private EditText edtreporte;
    String spath = GlobalInfo.PATH_IP;
    private ProgressDialog pDialog;
    Bitmap bitmap;



    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        edtreporte = findViewById(R.id.reporte_field);
        edttitulo = findViewById(R.id.name_field);
        edtzona = findViewById(R.id.zona_field);
        edtdescripcion = findViewById(R.id.email_field);
        txtestado = findViewById(R.id.estado_field);
        edtidActividad = findViewById(R.id.id_field);
        edtreporte = findViewById(R.id.reporte_field);


        AndPermission
                .with(this)
                .permission(Permission.READ_EXTERNAL_STORAGE, Permission.WRITE_EXTERNAL_STORAGE)
                .onDenied(new Action() {
                    @Override
                    public void onAction(List<String> permissions) {
                    }
                })
                .start();

        foto = (ImageView) findViewById(R.id.industry_menu);
        foto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cargarImagen();
            }
        });


        Bundle param = this.getIntent().getExtras();
        if(param != null){
            xid =  param.getString("id");
            xzona =  param.getString("zona");
            xtitulo = param.getString("titulo");
            xdescripcion =  param.getString("descripcion");
            xestado =  param.getString("estado");
            xreporte = param.getString("reporte");
            xfoto = param.getString("foto");
            zonas = param.getString("zona");
            fkzonas = param.getString("fkzona");
            ids = Integer.valueOf(param.getString("id"));
            edtidActividad.setText(param.getString("id"));
            edtzona.setText(param.getString("zona"));
            edttitulo.setText(param.getString("titulo"));
            edtdescripcion.setText(param.getString("descripcion"));
            txtestado.setText(param.getString("estado"));
            edtreporte.setText(param.getString("reporte"));
            if(!param.getString("foto").equals("")){
                Glide.with(this).load(spath+"/"+param.getString("foto")).into(foto);
            }
            /*
            String[] separated = client.getFecha().split("-");
            String ano = separated[0];
            String mes = separated[1];
            String dia = separated[2];*/
        }


        imagen = (ImageView) findViewById(R.id.imageView);
        imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( MainActivity.this,UbicacionActivity.class );
                intent.putExtra("id",""+xid);
                //intent.putExtra("fecha",""+note.getFecha());
                intent.putExtra("titulo",""+xtitulo);
                intent.putExtra("descripcion",""+xdescripcion);
                intent.putExtra("zona",""+xzona);
                intent.putExtra("fkzona",""+fkzonas);
                intent.putExtra("estado",""+xestado);
                intent.putExtra("foto",""+xfoto);
                intent.putExtra("reporte",""+xreporte);
                startActivity(intent);
                //  LoginUser(ausuario, acontrasena);
            }
        });


        sbButton = (Button) findViewById(R.id.sign_up_button);
        sbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              String xreporte = edtreporte.getText().toString();
              String xidactividad = edtidActividad.getText().toString();

              if (!xreporte.isEmpty()) {
                  EnviarInforme(xidactividad, xreporte);
              } else {
                 if(edtreporte.getText().toString().equals("")){
                     edtreporte.setError("El campo no puede estar vacio");
                 }
              }
            }
        });
    }


    private void cargarImagen() {
        final CharSequence[] opciones={"Tomar Foto","Cargar Imagen","Cancelar"};
        final AlertDialog.Builder alertOpciones=new AlertDialog.Builder(this);
        alertOpciones.setTitle("Seleccione una Opciòn");
        alertOpciones.setItems(opciones, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (opciones[i].equals("Tomar Foto")){
                    abriCamara();
                }else{
                    if (opciones[i].equals("Cargar Imagen")){
                        Intent intent=new Intent(Intent.ACTION_GET_CONTENT, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        intent.setType("image/");
                        startActivityForResult(intent.createChooser(intent,"Seleccione la AplicaciÃƒÂ³n"),COD_SELECCIONA);
                    }else{
                        dialogInterface.dismiss();
                    }
                }
            }
        });
        alertOpciones.show();
    }



    private void abriCamara() {
        if (Build.VERSION.SDK_INT> Build.VERSION_CODES.LOLLIPOP_MR1) {// Marshmallow+
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                } else {
                    ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA}, MY_PERMISSIONS_REQUEST_CAMARA );
                }
            }else{ //have permissions
                tomarFotografia();
            }
        }else{ // Pre-Marshmallow
            tomarFotografia();
        }
    }


    private void tomarFotografia() {
        try {
            File fileImagen = new File(Environment.getExternalStorageDirectory(), RUTA_IMAGEN);
            boolean isCreada = fileImagen.exists();
            String nombreImagen = "";
            if (isCreada == false) {
                isCreada = fileImagen.mkdirs();
            }
            if (isCreada == true) {
                nombreImagen = (System.currentTimeMillis() / 1000) + ".jpg";
            }
            path = Environment.getExternalStorageDirectory() +
                    File.separator + RUTA_IMAGEN + File.separator + nombreImagen;
            File imagen = new File(path);
            Intent intent = null;
            intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                String authorities = getApplicationContext().getPackageName() + ".fileprovider";
                Uri imageUri = FileProvider.getUriForFile(this, authorities, imagen);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            } else {
                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(imagen));
            }
            startActivityForResult(intent, COD_FOTO);////
        }catch(Exception e){
            Toast.makeText(getApplicationContext(), " Error "+e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
       // Toast.makeText(getApplicationContext(), "requestCode "+requestCode+" path: "+path, Toast.LENGTH_LONG).show();

      //  if (resultCode==RESULT_OK){
            switch (requestCode){
                case COD_SELECCIONA:
                    Uri miPath=data.getData();
                   // Toast.makeText(getApplicationContext(), "miPath "+miPath+" SELECCIONA: "+COD_SELECCIONA, Toast.LENGTH_LONG).show();
                  //  foto.setImageURI(miPath);
                    try{
                      bitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), miPath);
                      foto.setImageBitmap(bitmap);
                    }catch(IOException e){
                      e.printStackTrace();
                    }

                    break;

                case COD_FOTO:
                    MediaScannerConnection.scanFile(this, new String[]{path}, null,
                            new MediaScannerConnection.OnScanCompletedListener() {
                                @Override
                                public void onScanCompleted(String path, Uri uri) {
                                    //  Toast.makeText(getApplicationContext(), "ruta "+path, Toast.LENGTH_LONG).show();
                                }
                            });

                  //  Toast.makeText(getApplicationContext(), "ruta "+path, Toast.LENGTH_LONG).show();
                    bitmap= BitmapFactory.decodeFile(path);
                    foto.setImageBitmap(bitmap);
                    break;
            }
      }




    private void EnviarInforme(final String sid, final String sreporte) {
      String tag_string_req = "req_register";
      pDialog.setMessage("Enviando ...");
      showDialog();
      String url = spath+"informe.php";
        StringRequest strReq = new StringRequest(Request.Method.POST,
                  url, new Response.Listener<String>() {
          @Override
          public void onResponse(String response) {
              hideDialog();
              Log.e("Error",response);
              try {
                  JSONArray respObj = new JSONArray(response);
                  for(int i = 0; i < respObj.length(); i++){
                      JSONObject c = respObj.getJSONObject(i);
                      String resultado = c.getString("insertado");
                      if(resultado.equals("1")){
                        //  nombre.setText("");
                       //   apellido.setText("");
                      //    usuario.setText("");
                         /*
                          Intent intent = new Intent(Paso3Activity.this, LoginActivity.class);
                          startActivity(intent);*/
                          new SweetAlertDialog(MainActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                                  .setTitleText("Registro Exitoso")
                                  .setContentText("Reporte enviado con exito")
                                  .show();
                      }else{
                          Toast.makeText(getApplicationContext(), "No se pudo crear el usuario", Toast.LENGTH_LONG).show();
                      }
                  }
              }catch (Exception e){
                  e.printStackTrace();
                  Toast.makeText(getApplicationContext(), ""+e.getMessage(), Toast.LENGTH_LONG).show();
              }
          }
      }, new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError error) {
              hideDialog();
              Toast.makeText(getApplicationContext(), "error: " +error.getMessage(), Toast.LENGTH_LONG).show();
          }
      }) {
          @Override
          protected Map<String, String> getParams() {
              Map<String, String> params = new HashMap<String, String>();
              params.put("id",sid);
              params.put("reporte", sreporte);
              params.put("evidencia", convertirImgString(bitmap));
              return params;
          }
      };
      AppCore.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    public String convertirImgString(Bitmap bitmap){
      ByteArrayOutputStream array = new ByteArrayOutputStream();
      bitmap.compress(Bitmap.CompressFormat.JPEG, 100, array);
      byte[] imagenByte = array.toByteArray();
      String imagenString = Base64.encodeToString(imagenByte, Base64.DEFAULT);
      return imagenString;
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, ListadoActivity.class);
        startActivity(intent);
        finish();
    }
}
