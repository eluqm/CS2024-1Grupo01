package com.example.notificacionesfcm;


public class GlobalInfo {
 // https://dogmasoftapp.cloud/Limperu/api/listadoid.php
 // http://192.168.10.11/
 // public static final String PATH_IP = "http://192.168.10.15/mockup/Limperu/api/";
  public static final String PATH_IP = "https://dogmasoftapp.cloud/Limperu/api/";
  //public static final String PATH_IP = "http://192.168.0.55/ApiLimperu/";
}
