/*jshint esversion: 6*/
// web que sirvieron

// fin de web que sirvieron

function initGimmiCoords() {
  var Mapa = cargarMapa(); // Cargo Mapa
  editorDePoligonos = drawingMan(Mapa);
  Geocoder = new google.maps.Geocoder();
  nuevoPoligono = document.getElementById('nuevoPoly');
  google.maps.event.addListener(editorDePoligonos, 'overlaycomplete', function (polygon) {
    //alert("Poligon "+polygon.overlay.getPath().getArray());
    $('#inputMarcador').val(polygon.overlay.getPath().getArray());
    // guardo coordenadas del poligono
    var newShape = polygon.overlay;
      newShape.type = polygon.type;

    google.maps.event.addListener(newShape, 'click', function (e) {
      var coordenadasGuardadas = polygon.overlay.getPath().getArray();
      //mostrarCoordenadas(coordenadasGuardadas);
      //alert(coordenadasGuardadas);
      $('#inputMarcador').val(coordenadasGuardadas);
    })
  });
}

// FUNCION PARA INICIAR EL MAPA
function cargarMapa() {
  var Mapa = new google.maps.Map(document.getElementById('map'), {
    center: {
      lat: -12.047221,
      lng: -77.032077
    },
    zoom: 15,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
  return Mapa;
}

// FUNCION PARA DIBUJAR POLIGONOS
function drawingMan(map) {
  var drawingManager = new google.maps.drawing.DrawingManager({
    drawingMode: google.maps.drawing.OverlayType.POLYGON,
    drawingControl: true,
    drawingControlOptions: {
      position: google.maps.ControlPosition.TOP_CENTER,
      drawingModes: [google.maps.drawing.OverlayType.POLYGON],
    },
    polygonOptions: {
      clickable: true,
      editable: true,
    },
  });
  drawingManager.setMap(map);

  return drawingManager;
}

function mostrarCoordenadas(coordenadas) {
  // creo elemento
  var coords = document.createElement("table");
  // lo lleno con las coordenadas
  coords.innerHTML = coordenadas + "<br>";
  // Agrego el elemento al DOM
  document.getElementById("listaDeCoords").appendChild(coords);
};
