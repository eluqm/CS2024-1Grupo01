<?php

require_once 'include/DB_Functions.php';
$db = new DB_Functions();
// json response array
$response = array("error" => FALSE);
if (isset($_POST['nombre']) && isset($_POST['correo']) && isset($_POST['contrasena']) && isset($_POST['nombre_negocio']) && isset($_POST['pais'])) {

    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $contrasena  = $_POST['contrasena'];
    $nombre_negocio = $_POST['nombre_negocio'];
    $pais = $_POST['pais'];
    $indicativo = $_POST['indicativo'];

    $user = $db->storeSolicitud($nombre, $correo, $contrasena, $nombre_negocio, $pais, $indicativo);
    if (true) {
        $response["error"] = FALSE;
        $response["user"]["id"] = $user["id"];
        $response["user"]["nombre"] = $user["nombre"];
        $response["user"]["email"] = $user["email"];
        $response["user"]["password"] = $user["password"];
        $response["user"]["nombre_taller"] = $user["nombre_taller"];
        $response["user"]["telefono"] = $user["telefono"];
        echo json_encode($response);
    } else {
        $response["error"] = TRUE;
        $response["error_msg"] = "Unknown error occurred in registration!";
        echo json_encode($response);
   }
}
?>
