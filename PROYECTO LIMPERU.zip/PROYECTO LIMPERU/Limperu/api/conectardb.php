<?php
function conectar()
{
    $servername = "localhost";
    $username = "u593576198_aplicaciones";
    $password = "A2d123456789*";
    $dbname = "u593576198_aplicaciones";

    $con = new mysqli($servername,$username,$password,$dbname);
    //verifica conexion
    if($con->connect_error)
        die("Conexion fallida: ".$con->connect_error);
        //devuelve
        return $con;
}
?>
