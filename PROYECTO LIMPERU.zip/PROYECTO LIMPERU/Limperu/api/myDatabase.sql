CREATE DATABASE tallermecanico;
USE tallermecanico;

CREATE TABLE usuarios(
  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `hash` varchar(500) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `nombre_taller` varchar(250) NOT NULL,
  `telefono` varchar(250) NOT NULL,
  `indicativo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
