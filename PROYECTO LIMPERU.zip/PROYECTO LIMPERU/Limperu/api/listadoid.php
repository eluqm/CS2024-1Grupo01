<?php
   include("conectardb.php");
   $conexion = conectar();

   $id = $_POST['id'];

   $sql = "SELECT l.id, l.fecha, l.titulo, l.descripcion,
        (SELECT zona FROM zona WHERE id = l.fkzona) AS zona,
        foto, reporte, fkzona, 
        (SELECT CONCAT(nombre,' ',apellido) FROM operario WHERE id = l.fkoperario) AS operario,
        (SELECT estado FROM estado WHERE id = l.fkestado) AS estado
        FROM labor AS l INNER JOIN estado AS e ON e.id = l.fkestado WHERE l.fkoperario = $id  AND  e.estado != 'Finalizada' ";

   mysqli_set_charset($conexion, "utf8"); //formato de datos utf8
   if(!$result = mysqli_query($conexion, $sql)) die();
   $usuarios = array(); //creamos un array
   while($row = mysqli_fetch_array($result))
   {
         $id=$row['id'];
         $fecha=$row['fecha'];
         $titulo=$row['titulo'];
         $descripcion=$row['descripcion'];
         $zona=$row['zona'];
         $area=$row['area'];
         $operario=$row['operario'];
         $estado=$row['estado'];

         $fkzona=$row['fkzona'];

         $foto=$row['foto'];
         $reporte=$row['reporte'];


         $usuarios[] = array('id'=> $id,'fecha'=> $fecha, 'titulo'=> $titulo,
         'descripcion'=> $descripcion, 'zona' => $zona, 'area' => $area,
         'operario' => $operario , 'estado' => $estado,
          'foto' => $foto, 'reporte' => $reporte, 
          'fkzona' => $fkzona
         );
   }

   $close = mysqli_close($conexion)
   or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
   $json_string = json_encode($usuarios);
   echo $json_string;


?>
