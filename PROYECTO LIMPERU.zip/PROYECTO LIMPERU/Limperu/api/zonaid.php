<?php
   include("conectardb.php");
   $conexion = conectar();

   $id = $_POST['id'];
   //$id = 4;
   
   $sql = "SELECT id, latitud, longitud, fkzona FROM coordenadas WHERE fkzona = $id ";

   mysqli_set_charset($conexion, "utf8"); //formato de datos utf8
   if(!$result = mysqli_query($conexion, $sql)) die();
   $usuarios = array(); //creamos un array
   while($row = mysqli_fetch_array($result))
   {
         $id=$row['id'];
         $latitud=$row['latitud'];
         $longitud=$row['longitud'];
         $fkzona=$row['fkzona'];


         $usuarios[] = array('id'=> $id,'latitud'=> $latitud, 'longitud'=> $longitud,
         'fkzona'=> $fkzona
         );
   }

   $close = mysqli_close($conexion)
   or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
   $json_string = json_encode($usuarios);
   echo $json_string;


?>
