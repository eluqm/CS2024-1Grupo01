<?php
    include("conectardb.php");
    //valores a ingresar
    $id = $_POST['id'];
    $reporte = $_POST['reporte'];
    date_default_timezone_set('America/Mexico_City');
    $now = date('Y-m-d H:i:s');
    $rol = 'usuario';
    $sincr = "1";
    
    $estado = "8";

    $evidencia = $_POST['evidencia'];
    $path = "imagenes/$id.jpg";

    file_put_contents($path, base64_decode($evidencia));
    $bytesArchivo = file_get_contents($path);

    //envia respues en json
    $dataArray = array();
    //funtion conectar de conectardb.php
    $conexion = conectar();
    //inserta los datos
    $sentencia = $conexion->prepare("UPDATE labor SET foto = ?, reporte = ?, fkestado = ? WHERE id = ?");
    $sentencia->bind_param("ssss",$path, $reporte, $estado, $id);
    $result = $sentencia->execute();
    if($result){
        $arrayDatos["insertado"]="1";
    }else{
      	$arrayDatos["insertado"]="0";
    }
    $dataArray[] = $arrayDatos;
    echo json_encode($dataArray);
    $conexion = null;
?>
