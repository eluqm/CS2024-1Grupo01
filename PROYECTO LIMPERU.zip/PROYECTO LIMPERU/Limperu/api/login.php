<?php
include("conectardb.php");
$dataArray = array();
if(isset($_POST['usuario']) && isset($_POST['clave'])){
    $username = $_POST['usuario'];
    $password = $_POST['clave'];
    $sincr = "1";
    //envia respues en json
    $conexion = conectar();

    $stmt = $conexion->prepare("SELECT id, foto, identificacion, nombre, apellido, correo, telefono, usuario, estado, clave  FROM operario  WHERE usuario=? AND clave=? LIMIT 1");
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows == 1) {
        $stmt->bind_result($id, $foto, $identificacion, $nombre, $apellido, $correo, $telefono, $usuario, $estado, $clave );
        if($stmt->fetch()){
            $arrayDatos["resultado"]="1";
            $arrayDatos["id"]=$id;
            $arrayDatos["identificacion"]=$identificacion;
            $arrayDatos["foto"]=$foto;
            $arrayDatos["nombre"]=$nombre;
            $arrayDatos["apellido"]=$apellido;
            $arrayDatos["correo"]=$correo;
            $arrayDatos["telefono"]=$telefono;
            $arrayDatos["usuario"]=$usuario;
            $arrayDatos["estado"]=$estado;
            $arrayDatos["clave"]=$clave;
        }else{
        	$arrayDatos["resultado"]="0";
        }
    } else {
       $arrayDatos["resultado"]="0";
    }
    $stmt->close();
    $conexion->close();
} else {
  $arrayDatos["resultado"]="2";
}
$dataArray[] = $arrayDatos;
echo json_encode($dataArray);
?>
