<?php
  session_start();
  require "../../class/db/clsController.php";
  $obj_cnsc = new clsCnsc();
  $tasignacion = $obj_cnsc->ConsultarCantidadAsignacion();
  $aisgnacion = mysqli_fetch_assoc($tasignacion);
  //echo $listar_usuarios['cantidad'];
  $tzona = $obj_cnsc->ConsultarCantidadZonas();
  $zona = mysqli_fetch_assoc($tzona);
  //echo $listar_noticias['cantidad'];
  $toperadores= $obj_cnsc->ConsultarCantidadOperadores();
  $operadores = mysqli_fetch_assoc($toperadores);
  //echo $listar_especialistas['cantidad'];
  $tpendientes = $obj_cnsc->ConsultarCantidadPendiientes();
  $pendientes = mysqli_fetch_assoc($tpendientes);
  
 
  
  $enero = $obj_cnsc->CantidadMesAsignacion(1);
  $ene = mysqli_fetch_assoc($enero);
  $febrero = $obj_cnsc->CantidadMesAsignacion(2);
  $feb = mysqli_fetch_assoc($febrero);
  $marzo = $obj_cnsc->CantidadMesAsignacion(3);
  $mar = mysqli_fetch_assoc($marzo);
  $abril = $obj_cnsc->CantidadMesAsignacion(4);
  $abr = mysqli_fetch_assoc($abril);
  $mayo = $obj_cnsc->CantidadMesAsignacion(5);
  $may = mysqli_fetch_assoc($mayo);
  $junio = $obj_cnsc->CantidadMesAsignacion(6);
  $jun = mysqli_fetch_assoc($junio);
  $julio = $obj_cnsc->CantidadMesAsignacion(7);
  $jul = mysqli_fetch_assoc($julio);
  $agosto = $obj_cnsc->CantidadMesAsignacion(8);
  $ago = mysqli_fetch_assoc($agosto);
  $septiembre = $obj_cnsc->CantidadMesAsignacion(9);
  $sep = mysqli_fetch_assoc($septiembre);
  $octubre = $obj_cnsc->CantidadMesAsignacion(10);
  $oct = mysqli_fetch_assoc($octubre);
  $noviembre = $obj_cnsc->CantidadMesAsignacion(11);
  $nov = mysqli_fetch_assoc($noviembre);
  $diciembre = $obj_cnsc->CantidadMesAsignacion(12);
  $dic = mysqli_fetch_assoc($diciembre);
  
?>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
            <!--<div class="nav-item dropdown">
                 <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa fa-bell me-lg-2"></i>
                    <span class="d-none d-lg-inline-flex">Notificaciones</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
                </div>
            </div>-->
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo $_SESSION['nombre'].' '.$_SESSION['apellido']; ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <!--<a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>-->
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->

<script type="text/javascript">
$("#salir").click(function(){
  swal({
       title: "Cerrar Sesion",
       text: "Realmente deseas salir de la sesion actual ?",
       type: "warning",
       showCancelButton: true,
       confirmButtonColor: "#034b7b",
       confirmButtonText: "Aceptar",
       cancelButtonText: "Cancelar",
       closeOnConfirm: false,
       closeOnCancel: false
      },
      function(isConfirm){
       if (isConfirm) {
         $.ajax({
             url:'pages/admin/logout.php',
             type:'post',
             success:function(response){
               window.location="index.php";
             }
         });
       } else {
          swal.close();
       }
    });
});
</script>

    <!-- Sale & Revenue Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Asignacion</p>
                        <h6 class="mb-0"><?php echo $aisgnacion['cantidad']; ?></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa-solid fa-map fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Zonas</p>
                        <h6 class="mb-0"><?php echo $zona['cantidad']; ?></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa-solid fa-user fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Operadores</p>
                        <h6 class="mb-0"><?php echo $operadores['cantidad']; ?></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa-solid fa-calendar-check fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Pendientes</p>
                        <h6 class="mb-0"><?php echo $pendientes['cantidad'];?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Sale & Revenue End -->
    <!-- Sales Chart Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Asignaciones</h6>
                    </div>
                    <canvas id="worldwide-sales"></canvas>
                </div>
            </div>
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light text-center rounded p-4" style="height: 300px;">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Donde Estamos</h6>
                    </div>
<!--                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12094.57348593182!2d-74.00599512526003!3d40.72586666928451!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2598f988156a9%3A0xd54629bdf9d61d68!2sBroadway-Lafayette%20St!5e0!3m2!1spl!2spl!4v1624523797308!5m2!1spl!2spl"
                        class="h-100 w-100" style="border:0;" allowfullscreen="" loading="lazy"></iframe>-->
                        
                    
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15309.641944097317!2d-71.54931255892325!3d-16.403965997189182!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x91424a487785b9b3%3A0xa3c4a612b9942036!2zQXJlcXVpcGEsIFBlcsO6!5e0!3m2!1ses!2sco!4v1718637239744!5m2!1ses!2sco" width="600" height="450" style="border:0;" class="h-100 w-100" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>
    </div>
    <!-- Sales Chart End -->

    <script type="text/javascript">
    var ctx1 = $("#worldwide-sales").get(0).getContext("2d");
    var myChart1 = new Chart(ctx1, {
        type: "bar",
        data: {
            labels: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
            datasets: [{
                    label: "Registros x Mes",
                    data: [
                        <?php echo $ene['id']; ?>,
                        <?php echo $feb['id']; ?>,
                        <?php echo $mar['id']; ?>,
                        <?php echo $abr['id']; ?>,
                        <?php echo $may['id']; ?>,
                        <?php echo $jun['id']; ?>,
                        <?php echo $jul['id']; ?>,
                        <?php echo $ago['id']; ?>,
                        <?php echo $sep['id']; ?>,
                        <?php echo $oct['id']; ?>,
                        <?php echo $nov['id']; ?>,
                        <?php echo $dic['id']; ?>
                        ],
                    backgroundColor: "rgba(0, 156, 255, .3)"
                }
            ]
            },
        options: {
            responsive: true
        }
    });

    </script>

    <!-- Recent Sales Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Informes</h6>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col"><input class="form-check-input" type="checkbox"></th>
                            <th scope="col">Fecha</th>
                            <th scope="col">Titulo</th>
                            <th scope="col">Descripcion</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Operario</th>
                            <th scope="col">Accion</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php
                       $resultado_cnsc = $obj_cnsc->ConsultarAsignacion();
                        if(mysqli_num_rows($resultado_cnsc)>0){
                          $cont = 0;
                             while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                              $cont++;
                            ?>
                              <tr class="dato">
                                <td><input class="form-check-input" type="checkbox"></td>
                                <td><?php echo $listar_repuesto["fecha"]; ?></td>
                                <td><?php echo $listar_repuesto["titulo"]; ?></td>
                                <td><?php echo $listar_repuesto["descripcion"]; ?></td>
                                <td><?php echo $listar_repuesto["estado"]; ?></td>
                                <td><?php echo $listar_repuesto["operario"]; ?></td>
                                <td style="text-align:center;">
                                  <div class="btn-group">
                                    <button type="button"  atrib="<?php echo $listar_repuesto['id']; ?>" class="ver  btn btn-primary btn-sm eliminar"><i class="fa fa-eye" aria-hidden="true"></i> Ver</button>
                                  </div>
                                </td>
                              </tr>
                              <?php
                               }
                             }else{
                              ?>
                              <tr>
                                  <td colspan="7" style="text-align:center;">No se encontraron registros</td>
                              </tr>
                          <?php
                            }
                          ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    
    <script>
     $('.ver').click(function(){
       var a = $(this).attr('atrib');
       funcionajax("pages/asignacion/editarForm.php","container",a);
     });
    </script>
    <!-- Recent Sales End -->
    <!-- Widgets Start -->
    <!-- Footer Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
                   LIMPERU-SERVICIOS DE LIMPIEZA Y MANTENIMIENTO DEL PERU
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
