<?php
  require "../../class/db/clsController.php";
  $obj_cnsc = new clsCnsc();
  if ($obj_cnsc->EditarOperador($_POST["id"],$_POST["identificacion"],$_POST["nombre"],
  $_POST["apellido"],$_POST["estado"], $_POST["correo"],$_POST["telefono"],
  $_POST["usuario"], $_POST["password"])) {
    echo "err:ok";
  }
?>
