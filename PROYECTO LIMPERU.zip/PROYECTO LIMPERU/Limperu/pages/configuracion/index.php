<?php
session_start();
?>
<!-- Navbar Start -->
  <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
            <!--<div class="nav-item dropdown">
                 <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa fa-bell me-lg-2"></i>
                    <span class="d-none d-lg-inline-flex">Notificaciones</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
                </div>
            </div>-->
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo $_SESSION['nombre'].' '.$_SESSION['apellido']; ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <!--<a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>-->
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
<!-- Navbar End -->

<script type="text/javascript">
$("#salir").click(function(){
  swal({
       title: "Cerrar Sesion",
       text: "Realmente deseas salir de la sesion actual ?",
       type: "warning",
       showCancelButton: true,
       confirmButtonColor: "#034b7b",
       confirmButtonText: "Aceptar",
       cancelButtonText: "Cancelar",
       closeOnConfirm: false,
       closeOnCancel: false
      },
      function(isConfirm){
       if (isConfirm) {
         $.ajax({
             url:'pages/admin/logout.php',
             type:'post',
             success:function(response){
               window.location="index.php";
             }
         });
       } else {
          swal.close();
       }
    });
});
</script>
<!-- Recent Sales Start -->
<div class="container-fluid pt-4 px-4">
    <div class="bg-light text-center rounded p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h6 class="mb-0">Configuracion</h6>
        </div>
        <div class="row">

          <style media="screen">
           .main-body {
             padding: 15px;
           }

           .nav-link {
             color: #4a5568;
           }
           .card {
             box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
           }

           .card {
             position: relative;
             display: flex;
             flex-direction: column;
             min-width: 0;
             word-wrap: break-word;
             background-color: #fff;
             background-clip: border-box;
             border: 0 solid rgba(0,0,0,.125);
             border-radius: .25rem;
           }

           .card-body {
             flex: 1 1 auto;
             min-height: 1px;
             padding: 1rem;
           }

           .gutters-sm {
             margin-right: -8px;
             margin-left: -8px;
           }

           .gutters-sm>.col, .gutters-sm>[class*=col-] {
             padding-right: 8px;
             padding-left: 8px;
           }
           .mb-3, .my-3 {
             margin-bottom: 1rem!important;
           }

           .bg-gray-300 {
             background-color: #e2e8f0;
           }
           .h-100 {
             height: 100%!important;
           }
           .shadow-none {
             box-shadow: none!important;
           }
          </style>

          <div class="container">
                <nav aria-label="breadcrumb" class="main-breadcrumb">
                  <ol class="breadcrumb" style="margin-top: 10px;">
                    <li class="breadcrumb-item active" aria-current="page">Configuracion del Perfil</li>
                  </ol>
                </nav>

                <div class="row gutters-sm">
                  <div class="col-md-4 d-none d-md-block">
                    <div class="card">
                      <div class="card-body" style="text-align:left;">
                        <nav class="nav flex-column nav-pills nav-gap-y-1">
                          <a style="text-decoration: none !important;" href="#account" data-toggle="tab" class="nav-item nav-link has-icon nav-link-faded active">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-settings mr-2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                            Configuraciòn de Cuenta
                          </a>
                          <a style="text-decoration: none !important;" href="#security" data-toggle="tab" class="nav-item nav-link has-icon nav-link-faded">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shield mr-2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>Seguridad
                          </a>
                          <a style="text-decoration: none !important;" href="#notification" data-toggle="tab" class="nav-item nav-link has-icon nav-link-faded">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell mr-2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>Notificaciones
                          </a>

                        </nav>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-8">
                    <div class="card">
                      <div class="card-header border-bottom mb-3 d-flex d-md-none">
                        <ul class="nav nav-tabs card-header-tabs nav-gap-x-1" role="tablist">
                          <li class="nav-item">
                            <a href="#profile" data-toggle="tab" class="nav-link has-icon active"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                              <circle cx="12" cy="7" r="4"></circle></svg></a>
                          </li>
                          <li class="nav-item">
                            <a href="#account" data-toggle="tab" class="nav-link has-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-settings"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></a>
                          </li>
                          <li class="nav-item">
                            <a href="#security" data-toggle="tab" class="nav-link has-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shield"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg></a>
                          </li>
                          <li class="nav-item">
                            <a href="#notification" data-toggle="tab" class="nav-link has-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg></a>
                          </li>
                          <li class="nav-item">
                            <a href="#billing" data-toggle="tab" class="nav-link has-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg></a>
                          </li>
                        </ul>
                      </div>
                      <div class="card-body tab-content" style="text-align: left;">
                        <div class="tab-pane active" id="account">
                          <h6>CONFIGURACIÒN DE LA CUENTA</h6>
                          <hr>
                          <form>
                            <div class="form-group">
                              <label for="username">Usuario</label>
                              <input type="text" class="form-control" id="username" aria-describedby="usernameHelp" placeholder="Enter your username"  value="">
                              <!--<small id="usernameHelp" class="form-text text-muted">After changing your username, your old username becomes available for anyone else to claim.</small>-->
                            </div>
                            <hr>
                            <div class="form-group">
                              <label class="d-block text-danger">Eliminar Cuenta</label>
                              <p class="text-muted font-size-sm">Una vez que eliminas tu cuenta, tus datos, configuracion y accesos al sistema se perderan .</p>
                            </div>
                            <button class="btn btn-danger" type="button">Eliminar Cuenta</button>
                          </form>
                        </div>
                        <div class="tab-pane" id="security">
                          <h6>CONFIGURACION DE SEGURIDAD</h6>
                          <hr>
                          <form>
                            <div class="form-group">
                              <label class="d-block">Cambiar Contraseña</label>
                              <input type="text" class="form-control" placeholder="Ingrese su antiguo contraseña">
                              <input type="text" class="form-control mt-1" placeholder="Nueva contraseña">
                              <input type="text" class="form-control mt-1" placeholder="Confirmar su nueva contraseña">
                            </div>
                          </form>
                          <hr>
                          <form>
                            <div class="form-group">
                              <label class="d-block"></label>
                              <button class="btn btn-info" type="button">Actualizar los datos de acceso</button>
                              <p class="small text-muted mt-2">Two-factor authentication adds an additional layer of security to your account by requiring more than just a password to log in.</p>
                            </div>
                          </form>
                          <hr>
                        </div>
                        <div class="tab-pane" id="notification">
                          <h6>CONFIGURACIÓN DE LAS NOTIFICACIONES</h6>
                          <hr>
                          <form>
                            <div class="form-group">
                              <label class="d-block mb-0"></label>
                              <div class="small text-muted mb-3"></div>
                              <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="customCheck1" checked="">
                                <label class="custom-control-label" for="customCheck1">Mostrar Notificaciones de Recoleccion Realizada</label>
                              </div>
                              <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="customCheck2" checked="">
                                <label class="custom-control-label" for="customCheck2">Email a digest summary of vulnerability</label>
                              </div>
                            </div>
                            <div class="form-group mb-0">
                              <label class="d-block">SMS Notifications</label>
                              <ul class="list-group list-group-sm">
                                <li class="list-group-item has-icon">
                                  Comments
                                  <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                                    <input type="checkbox" class="custom-control-input" id="customSwitch1" checked="">
                                    <label class="custom-control-label" for="customSwitch1"></label>
                                  </div>
                                </li>
                                <li class="list-group-item has-icon">
                                  Updates From People
                                  <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                                    <input type="checkbox" class="custom-control-input" id="customSwitch2">
                                    <label class="custom-control-label" for="customSwitch2"></label>
                                  </div>
                                </li>
                                <li class="list-group-item has-icon">
                                  Reminders
                                  <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                                    <input type="checkbox" class="custom-control-input" id="customSwitch3" checked="">
                                    <label class="custom-control-label" for="customSwitch3"></label>
                                  </div>
                                </li>
                                <li class="list-group-item has-icon">
                                  Events
                                  <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                                    <input type="checkbox" class="custom-control-input" id="customSwitch4" checked="">
                                    <label class="custom-control-label" for="customSwitch4"></label>
                                  </div>
                                </li>
                                <li class="list-group-item has-icon">
                                  Pages You Follow
                                  <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                                    <input type="checkbox" class="custom-control-input" id="customSwitch5">
                                    <label class="custom-control-label" for="customSwitch5"></label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                          </form>
                        </div>
                        <div class="tab-pane" id="billing">
                          <h6>BILLING SETTINGS</h6>
                          <hr>
                          <form>
                            <div class="form-group">
                              <label class="d-block mb-0">Payment Method</label>
                              <div class="small text-muted mb-3">You have not added a payment method</div>
                              <button class="btn btn-info" type="button">Add Payment Method</button>
                            </div>
                            <div class="form-group mb-0">
                              <label class="d-block">Payment History</label>
                              <div class="border border-gray-500 bg-gray-200 p-3 text-center font-size-sm">You have not made any payment.</div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

        </div>
    </div>
</div>

<div class="container-fluid pt-4 px-4">
    <div class="bg-light rounded-top p-4">
        <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-end">
                LIMPERU-SERVICIOS DE LIMPIEZA Y MANTENIMIENTO DEL PERU
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->
