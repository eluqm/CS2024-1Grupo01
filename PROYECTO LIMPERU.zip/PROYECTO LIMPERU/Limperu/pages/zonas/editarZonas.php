<?php
  require "../../class/db/clsController.php";
  $obj_cnsc = new clsCnsc();
  if ($obj_cnsc->EditarZona($_POST["idinputzona"], $_POST["inputNombre"],$_POST["inputMarcador"],
  $_POST["slcEstado"])) {
    echo "err:ok";
  }
?>
