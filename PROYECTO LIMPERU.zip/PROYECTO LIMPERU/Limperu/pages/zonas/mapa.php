<!DOCTYPE html>
<html>
<head>
	<link type="text/css" rel="stylesheet" href="../../css/stylesheet.css" />
	<script type"text/javascript" src="../../js/scripts.js"></script>
	<title>GimmiCoords</title>
</head>
<body>
	<div id=sitio>
		<div id=contenedor>
			<!-- titulo -->
			<!-- buscador -->
			<div class="buscador">
				<input type="button" id="nuevoPoly" value="Nuevo Poligono" />
			</div>
			<div id="map">
				<!-- cargo mapa -->
				<script async defer
					src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBbVLeBUTYbsScQesmAsu2D6Wk2PQUVrCU&libraries=drawing&callback=initGimmiCoords"></script>
			</div>
		</div>
		<!-- Barra lateral -->

	</div>
</body>
</html>
