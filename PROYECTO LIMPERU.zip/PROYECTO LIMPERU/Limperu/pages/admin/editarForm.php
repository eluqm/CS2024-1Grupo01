<?php
  session_start();

  header("Cache-Control: no-store, no-cache, must-revalidate");
  require "../../class/db/clsController.php";
  $obj_mantenimiento = new clsCnsc();
  $resultado = $obj_mantenimiento->ConsultarIdAdmin($_POST['id']);
  $listar = mysqli_fetch_assoc($resultado);
?>

    <!-- Navbar Start -->
     <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
            <!--<div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa fa-bell me-lg-2"></i>
                    <span class="d-none d-lg-inline-flex">Notificaciones</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
                </div>
            </div>-->
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo $_SESSION['nombre'].' '.$_SESSION['apellido']; ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <!--<a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>-->
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->


<script type="text/javascript">
$("#salir").click(function(){
  swal({
       title: "Cerrar Sesion",
       text: "Realmente deseas salir de la sesion actual ?",
       type: "warning",
       showCancelButton: true,
       confirmButtonColor: "#034b7b",
       confirmButtonText: "Aceptar",
       cancelButtonText: "Cancelar",
       closeOnConfirm: false,
       closeOnCancel: false
      },
      function(isConfirm){
       if (isConfirm) {
         $.ajax({
             url:'pages/admin/logout.php',
             type:'post',
             success:function(response){
               window.location="index.php";
             }
         });
       } else {
          swal.close();
       }
    });
});
</script>


    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-xl12">
              <form id="AddFormAdmin">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Formulario Editar Administrador</h6>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo $listar['nombre']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Apellido</label>
                            <input type="text" class="form-control" id="apellido" name="apellido" value="<?php echo $listar['apellido']; ?>">
                        </div>

                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Correo Electronico</label>
                            <input type="text" class="form-control" id="correo" name="correo" value="<?php echo $listar['correo']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Usuario</label>
                            <input type="text" class="form-control" id="usuario" name="usuario" value="<?php echo $listar['usuario']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Contraseña</label>
                            <input type="password"  class="form-control" id="password" name="password">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Estado</label>
                            <select class="form-select mb-3" aria-label="Default select example" id="estado" name="estado">
                                <option>Seleccione un estado</option>
                                <option <?php if($listar['estado'] == "activo"){ echo "selected";}  ?> value="activo">Activo</option>
                                <option <?php if($listar['estado'] == "inactivo"){ echo "selected";}  ?> value="inactivo">Inactivo</option>
                            </select>
                        </div>
                      <button type="submit" class="btn btn-warning">Guardar Datos</button>
                   </div>
               </form>
            </div>



        </div>
    </div>


    <!-- Footer Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
                    Software para gestion de tareas Limperu</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
