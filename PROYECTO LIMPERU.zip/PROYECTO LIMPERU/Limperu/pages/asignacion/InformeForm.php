<?php
session_start();

?>
    <!-- Navbar Start -->
   <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
            <!--<div class="nav-item dropdown">
                 <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa fa-bell me-lg-2"></i>
                    <span class="d-none d-lg-inline-flex">Notificaciones</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
                </div>
            </div>-->
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo $_SESSION['nombre'].' '.$_SESSION['apellido']; ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <!--<a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>-->
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->



<script type="text/javascript">
$("#salir").click(function(){
  swal({
       title: "Cerrar Sesion",
       text: "Realmente deseas salir de la sesion actual ?",
       type: "warning",
       showCancelButton: true,
       confirmButtonColor: "#034b7b",
       confirmButtonText: "Aceptar",
       cancelButtonText: "Cancelar",
       closeOnConfirm: false,
       closeOnCancel: false
      },
      function(isConfirm){
       if (isConfirm) {
         $.ajax({
             url:'pages/admin/logout.php',
             type:'post',
             success:function(response){
               window.location="index.php";
             }
         });
       } else {
          swal.close();
       }
    });
});
</script>






        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-sm-6 col-xl12">
                    <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Formulario Editar Asignacion</h6>
                          <div class="mb-3">
                              <label for="exampleInputPassword1" class="form-label">Fecha</label>
                              <input type="text" class="form-control" readonly value="<?php echo date("Y-m-d H:i:s");  ?>" id="exampleInputPassword1">
                          </div>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Titulo</label>
                                <input type="text" class="form-control" id="exampleInputEmail1"
                                    aria-describedby="emailHelp" value="Limpieza del parque central" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Descripcion</label>
                                <textarea name="name" rows="4" cols="40" readonly class="form-control">Realizar limpieza del parque central y recoleccion de residuos solidos
                                </textarea>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Operario</label>
                                <select class="form-select mb-3"  id="slcoperario" readonly name="slcoperario">
                                  <?php
                                    require "../../class/db/clsController.php";
                                    $obj_cnsc = new clsCnsc();
                                    $resultado_cnsc = $obj_cnsc->ConsultarOperario();
                                     if(mysqli_num_rows($resultado_cnsc)>0){
                                       $cont = 0;
                                          while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                                           $cont++;
                                          ?>
                                          <option value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['nombre'].' '.$listar_repuesto['apellido']; ?></option>
                                         <?php
                                          }
                                        }else{
                                         ?>
                                         <option value="">No hay Operario</option>
                                       <?php
                                        }
                                     ?>
                              </select>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Zona</label>
                                <select class="form-select mb-3"  id="slczona" readonly name="slczona">
                                  <?php
                                    $resultado_cnsc = $obj_cnsc->ConsultarZona();
                                     if(mysqli_num_rows($resultado_cnsc)>0){
                                       $cont = 0;
                                          while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                                           $cont++;
                                          ?>
                                          <option value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['zona']; ?></option>
                                         <?php
                                          }
                                        }else{
                                         ?>
                                         <option value="">No hay Zona</option>
                                       <?php
                                        }
                                     ?>
                              </select>
                            </div>

                      </div>
                </div>
                <div class="col-sm-6 col-xl12">
                  <div class="bg-light rounded h-100 p-4">

                  <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Evidencia</label>
                       <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSExMWFRUWGBgYGBgXGBgWGBodFx0YFxgYHRoaHSggGBolHRcaITEhJSorLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAAIDBQYBBwj/xAA/EAABAgMFBQYDBQgDAAMAAAABAhEAAyEEBRIxQVFhcYGRBhMiobHwMsHRFCNCUuEHM2JygpKi8RWywhYkU//EABgBAAMBAQAAAAAAAAAAAAAAAAABAgME/8QAIxEAAgICAgIDAQEBAAAAAAAAAAECERIhAzETQSJRYTLBgf/aAAwDAQACEQMRAD8A9qtMtxSAhNUk0qk6GsWExRGjwJPRiSVilNd2cADu/Sp5b/Ek+dCI8UvJZWtR/ESHH8QASY9VvOVVJDpUHcbXb6R5xf1hMqaXHiLGj1BFDXVm6RM+iWZO+UjSLD9lQX/yUvA4dK3OjAOX3UHlAN75e/eyCv2X23urzkPksqln+tJA/wAsMZxXyQrPYrRaQo9wpOJOMlTkg5uag0/WMRawkTZmEeELVh4Alo2V93SJa+9LGWQQsZEAvsEYNa041YRRywJB82rGrBhoTQ1aI8Nac4bLminvOJAoDQb4aRNjlqLM1ILloo527YEximUTCdwikhWXtw3h3SvhxYs66fWHdobUZkwKbClgBXOr/OKKVbS7sAR7eC/tuMVZ+EOgspL0vsWeYEd2pThwcWFJ21rlwh8++F913yrOoIwlWLHLIYAKJzBZtz0jt+WFNol4FM5fCoAuk7R89sVd+XoZlmFkQAJs090qX+XAPEdyMKjxCoH0VxLKVMGuPtVOtM1Pdyu7Qmqi74Q1DioyioUSxprrGnvW3qmrC1lJLAbOB4wFd9kRIlJloyGZapOqjveHrma/KFTrYpSTeiCctgKhuMNDKyIh8xdP0iOVOINDENCsj79ISo0oD5B4wxDk60B9Y2N6TGlL3pbrT5xkZC6zDvb0+sZzRSKu81U5tEt0pdSANVAdS0D3qajjF52KsiZlrs8tRwpUup2MCoekZJfJIn2bqcshWmmWW2La5bv79K2UkEB2UCHSnMg5bjE0m6RL73vwoFCXDZOoeAuN4Ii+ueyDEFqW8v4GdmKwGy0LtxjoUSjL2wLkTBMevhUkhzQUA/xblFZ+0++ZUyz2ZMtLLVMM0gJYOUkLG8uT1Ea28JacE6zkgFCscsk/EkuyQduXnHnfaGQ32RS1eArnEAFyFJEoEPo7gjhA7SYEd+20y5aAkAlRavA184rrrQCuXMUclfCGzSxDnQNF72g7OzZhkgkI8OIZmihQ/wCPnCsPZfu041TAfCqhDAFSSBUnfEYu7E36A595Jm/dLw92F0KVJNUkKFQahwIJvme1nmKBrgU39XhHrFXfXZdcuQq0klSkBSsKWq35ktUbaxwWgTrvswJJmTJiUL4BWIH/ABg/pExtN7tGhu+ThlITsSkeQeFBSU0pChmh69MQ/WOSkMCNHPQwNY70lTQ6FA5OBmHypE8y0MtKCPiBY6ONI0LB70sgWh2DprXdGP7XWQTDJKanuiktsDj1eNvarWiWAVlgSxOgfJ9kCyLvHeqmFiAGSGoHqYPQjxa/rsKEHEGPs/LzjMXEoptMtSSyknEDqCBiEfR963FItCCiYgEbRQjmI8ht3Z1FktnhxEpfM5u4fgQRSMnF2KRurZe4tVlSMQTNxJDD8QVmW2NmN0Y632VUmcqWuiknTIg1BG5oDRfCZctSVpJBThQpKwCkg+FTcUxRTL4dTkkmgqXoKDyjRtEGnlreutIIK4zki34qVghV46vFJoRciaKVhwnVz0jNTb1AS+Kr1FdYr5t/Mc3gyQUbdcxjXk7VpEyJzjYYxEvtACyTmIsZN7OMxDUkKjR2y0plpK1FkpqSWyihsiZgJtyxVdChqok0Zv4qYjugG8LxE2YmWoju0EKmB/iVmlHAZkcBB1ov6WPxA83gyT2ayWEcfb7/AD8/1mikzpZBdRDpJS1QTmH3HbAE2YN8ZeRfqUOkHwCqdwP4eAOW6IbR2iGh99IbkjFGmVODVLZwPMnpGvnGPn3ySaOYiXe6vy+sZOaKo2C5YnDBiaj/ANtYkuXsmFysalEOS41fTPbnFP2MtpmT1hSXAkrIGVXQn/0ekenoShMlKNgqB4mVhFCz1yilFS2FnlHaXs+lM9KEOXcsTvAZ/ecXlzdne7UhaQcaasM8tN+vWFfMtSrSgAnCAXOepPyiwmX3Lsy5S5icSfF4T/KRXdXMVGekLFLYGxn3unCiQZZVMI7uYFBjnQAfmo438YitipUqdJ7teOVhAUQXDlwk55h3Y7IxV69r1zVyLUQFIQRiTmRhViIWN756iF2uv6ymb3tkU6JlVIrQ0qxyLu40PGDNFNGov9SpJwTUEkF0rOwBsOxQHzgKyypUwmZ3SFgJYomVqaeF+GcZlfbBc+WZE0lSkg4CpwQQzp8ok7LXsqYpKMILg4yaMkZV5+QiXJAaW8r2C0SECpQgYlHMsAMPAPGdvy9QFYBkip3q2cvXhHZ16iXLUjCFTlBKU0cpAzLbX/WKS3XatGBcw1JJwirPk51Vm+ghcknWjKTLmyX6UpAWk8CRlqwBz3cYXZ2xFMpSwRg75RCQXCcTkYf4WaK+yXhIyKgkjXEFeQfo0WV0T3mplyziSolSEgMHBq4LMH1IGcQnXZMbNB9nmigBYbxCjIzu2ZSpSSVJIJBGwvUdYUa5I3tG07P21J8K1KCQ5QtCWXzA/wBRvpE5M+UBjdQI8aUKZ0kFxTdGDs0uRKUwTKpqMawDqcS6HkOkXVnvIsFTLeEIFGT3fqU4tukRGWzSy8tV2pm4vvcKlE/AQrkXH+ok7P2MSwtppmhRcPkGoW6eUUcm32WYgqNtnsHGILXLSNwoATxg7ssLOlUwSJhmOElRKsR1w66+KKTV6FZpIwX7R0hE2ROcMM+RB+Z6Ru0KcPGV/aMHkSwWI70ODlkaU0zixS6PH7xuVZSbQZ8kIWSQAoFXDBQg8WjPmSHcrPIN8zWPcb27PSJSFTEyJJwj4QD0wkeI8THnF62wlTS5CUAigFnCVDcCVFxvcxzsTRmUT0p/GuvXdX9ImU5DjG1Kqf5aRaTb4tSB3aypIZsJSlFDXJoBl2vxOuWle11KH/Rmh7BUOFz+EnGFFnYFvX6QHNuouPxPsOJtGO/dFzPvwlPdypKJQ3KWo8itRaAzOnGpCS2uEHzh0V8fSOXDcCJs0S5neJUpSUpCQ5OJ8ySyasN+KJLRLsSFgIRa1B2aYZSFYhmzA0DawTYbxMvHMYBQMshWEBTiYiZU7Pu9sB3vIAtE1TOCrEmgIwrZb5Zl/IRoqUAUUnsHs2BI8UjFiNMU0iurkEb+sSzJ6E5WeWDsdS/WYfQRFhBySx/prywx0oalPL5CJyoUnk7fshtc5Sik4UIaowBIfjm4iwu28JmNDqZClBNAkZ00GkQJIAyU+3ER5NHTNOEpdwDiq7gnUHpDhO2ZSrtAk1CgpWJioKOJ61BrptiNQ3AdYvr7sRVNVMQh0rZY/qAUfMmKxVkIzERJpNlp6L/9nyCZy3qEyy251JP/AJjdC0YQQ1G2MaMfnn9IxnYeSxnF2okZtt88o1tqqlICjiKQS54HzBMdHH/JLZl54ecdwy4l4r7+mIxpSpGMBFPEEMS1ci+WVIs0gGYTtHpQ+kUF7DFNUXOjDls4vEcmkEexlhkqWWM2WhAp4phSG2NUtwEXsqwWahTarKgihaXPNMndtmjRnO5oK+UFSJcwhkrU2TYqcGeObKPsvyUWVtsFjxpP2mThqCUS5in/AKTiKSeET95YpPikTlTFPqgyxTIsQDiz3UjPrsdWZuNId9ibZxBeBSXonyF0qZKxrUhOEKqSVpJ6cBkIqO1dqExDAfCkvoakFiG3RwSQDTyil7U23CBKAqfETqdgc6RTnaomyvs0w/hS7bM421zyZaChfefe0P4gAdUjQxibuCkLBIbI9aiN0iSFVCSxD5Oa8Il9AnRaWi67POUZpnTZZWcRSFEAE5sHo5q2+FA0qypYfdpPEsf+0ciTTyfgLhkg/eCar+VSRxzBeH93IIaXJmjni9AIkXPnk4ZcxbKpRKUDkEhhyiws1kCR98vSqe7lLJ/qWoq6CNsQKxFtSl0r7xI/KlQA5hQIMbT9m05M2dNwzFFghTE6OpKhQAfi02CMtakWQDwom8Wlh/8AD5xpP2bTZffzUolqB7qpJGWIaARUI0wNte959yUl81VFXIoGA211+cA/tBY2V2BIUkg7Kj5GIu2XwE0ejKz2EZimTchwiive9CqylJ0o3IVfiAOcbCb7R5mu2zUkgLI0cZ9RB9lvyakEd5OLhqTMFNmRPnEU6yTVKUpMtag/xBLjq0CDGVM5ByoG/wCojBrY1oLnzcTkycZzJKpiiOJCore+2SwesWS7qWxUsrHFCnP0HGI7DdpWAfEA7OE4v1hUisQWTPR/+RP9RbyEE2udLAGGUA+fiUPVn6RbybBZ1HAq0GUzfEhRCtzaczEd4yCn92QtIyKZSUjqQ7wy1HRRS7UFpwpl4wpRCxgLAJFWLgjMeINm3Eq8UjwFQUjwszOfDQZtRiIJsQnDErvkylAEDF3mIuXIBSktWEV2xbkhc5RIZSwZtOKn1yik/QmrorFpQAPESeBbhpEQBOXrG1lWGR9nInzFd8B8OBgniUkk8hyitu2wBaiiWZBH51oYf5B/KJsrAopcp/zltiSfSD7gtsqWVd8ibVRKcJQNABRaFRpRdaQgkz5QUzDulKlHhhKG5vAUi75CD48TsSSHLg7QA/kYVoFxMq1KRLTjwTFyyVJlJCkYkrFTLU8sg1UCAAPiIq0WNhloArYVqUoYSVLJrtCQkAV2CKW+lA4sKlKSauQW3F1AF9++GXbeMxKfAsKVTwYklR4JLk8otxU1Zj/EsX0+jX3NZRLStJBDqBIpRshSCpyMKcYFTw4k8WI3RFd0wiQFqzLk7a1/TrCtqh3aXJJq2wZD6dI2iqjREu9FYTV90A2iesktVOTsKNxEFWlbNsCRWKi0KnLGLASAMRKasBR6ZByIy5laSHFE8uU5dQKhqBQ9WgpEpBPgQpL5CqjltCYqZF6EZjHTV26QfZu0WFT4WGoHvKOVpoHSDUSpDELBCshimFgeGD5xABJR8Se8/lU3sQy2do5asX/10ORQl/CWozUpvijE0k5wiHJBtqnJQCs0Hum+MzZZBtU8zFBkDMeifmYur2ROmSUINEIKlB9qmc78vMxDY1hCAhgG3ZnUw7S6E2hnaGX8M0UIZJ2Np73wfc14FSGBII2E5QPaPGlSCcwRw2RW9n1KStKaEuRtyz5Rcd6A1otBGRPn8oUdTZdw6/WFG2JRJOt8tIIeWAfy/eL6g4YGCjMfu5Uxe8nABxZx5iNBdtispZT2dH8UxQxccOMfOJPtNhBCXXPKTQIGBAO2gST5xJtRl5N0zVKLlEsDVRp1ALxquwQVKtEwGbjBs8wBsQSC6C9QBkD1gi03/JKQgJThNPFUdAacS8Edn7Ykz+7ljNEzxDCR8JLZQ4P5A4pI119oeWCpqJpUUdvlrGJtSR9nWAXOZOn4QfIRr+0qzhIdwQGBDgUr5F+Uef2uaQkoqAxJD7VEB+Qjf0ZPsDRe9pUnuO8SJSQzOEluVTnE132Q/D3qQn+BK1dT4SeTxy6UFVEzFJUSwABU/IN6xai65ktsc1KSr8KW7w7csusc0ns6YR0U9pu2zBWDEolWS1qKEJO3DgCup5wUns1IcJ+1S1igJQUgg8yTBt43QkIxBlA5pUQnmcLmKaTdRrMSpKUgs6qjgHJKuYhZFYU+i4t/Z+xy0ulWNf5SVFPEqSUfLjFDavtIZMtOFOglEqH/AHWfOLqXailOAziBR+7Iw80JSmnWOI7ToBwNKWkfnxoBP8oBr0gTZbii2uC6JkySCmWqYr8WJckS/wDA4x5xbJ7ITQVTEzEySRlJXNT1OvSKC09pbMEDu1rQT8SJJwD+5RJ8ozNrv6ZieSu0oL5qnqUN1GEUhN17NdeHZ+0lOI221LbRMqa/9ylJcb4y94oky1gTBaVqOeKYkV492S+6AZ1/W8u9pnsMyFrA60isVeUwl1LKjtV4vWG9kZUbK7b4kyknCuZKbYjEf7mAfiIp74vifaVeEqIGq+5Ci20pQk9SYz0+2LX8SiYhUTqesJRB8lhxtihRSUKO0h/MGJf+VnzVJSVAZDwoQgtxSkRXJWdC0H3Qk4ir8uXExSjshydG2syRgFOvlAl8EDc6RkekFj4BVvCBns13OYp7zn4mDuw9M/WOg5wS8pxFNQkcXhllvZZSyp8xJOgFOe2BLa+BSiaqVt2MW84BlW5SMmcZEhzHLzK2MupUizAnvpjDMMl1Hblk8UtrmIKj3YITo5D+UDzrQSSolyczSGi0AaAxhg0Q0yaXKCojWhqQ6XPDvhcbI7OnhWScOwCo84KYmiNSzqfOEAwjgQc4kK+ES0Q1QpMxiDkeR9YnlTky1GYpgDmyEhn18AfVoDKOEMml0sQ784qEmgRfIvOU37xHWORmPsqBQj1jkbeQvI0vdh9vlBMgB/3YOz4vq0Frsp2JQHZslHiHJ9M40t39lJ5SlbS0jMd6pSieEtIbrDR0YlPYrtmLqJUtA/MopUXanhJr01iyukTZU9KzjKQC6lJKAKHJPlpGqFgvJSQlM6WhAD/dpSk0/CAPqIo7tu+eue89doUUkjx94pAoRUgYEiu2KSKLTtDbgWpTdw8J6RhLdMUCVENRgN3ijT3qkpUUqq+BQ2skFBy0Cc+AjK30QEk50pWtTk3KN2YFh2PuefagQib3ctJqrCVVodGBzGZgu97ts1ndKpy7RM1aYmWByS7f3RF2EkpNnnFcxSUCYNQAfCmmY2eccvG1XfpKoNEgkne+IDzMc0nujqitIpbRa0MEoloPFWJ+JJgaZeCvhTKQG1AJPUmJrVecsK8CO7GXhFeZJPlFZarwSok4fMwgb/TuHGXJHMgRHMwPQBuJgJc/WIwomKJsPmLQ1H6xFLnqfw+j5QKqJ5dqUBhSANpAqecAEs21rWR3i1KGx3bgDQQeg2QI+GYpTbQIp2UTWDLvu2ZNVhSOJNAneTpDq9BYPMWH8II8/OOJi2vG6RLQFB1MWUdH0bYKZRXMNsNqhXZwJDRZXWoVArl78oAxABhnHJVoMsukVZm+e+EnTIfZq5tuCi9duwe39IEnOVKoSyXy2xRybWUkO5Ll9nHZEs29FklQo7DN8gwjTyL2S9D73mNLSAWcksN7H5RThBO+Cioku7/KJkgboxbUtkoBTIMdMjfBcwZtR97xHh1Pv20ZttMTsYJWRcHrSF3e3KJEDbQvDlKioyTC0yMIpHBJqYmRLKqAQlJI0gaQUQKl7vWEQ0Tv7+UOKRESiiXFA/dGFBYRshRNAe2mTd9kHi7tSxqplrJGmuHk0PkX06cUiQlCSwxzPAnyDmM7d1gxFrKEqw5zTLoeD/WNHariWsPNWZzZJYBPTXnHTbOsmn3gnCROnoG3uCQeBzI4giKKzXxZVTRJld+SrESuZMVhGEFVcaiTl5xZSZaZSCVykoRWimA00AjLX7fshcvu5EoILviCcIoRkN4HpCyYpaLS8aKUUlJIlhQYg0OzQERhL5lTAgkJGHCC+4PmPKFaL4nJUUyyU1dqMcs6MRAdtts6YnCo5DIimpHvfGnkiznK6VeHdhjUEiherQrd2hQRhRJCVakknoAzecQSLCSHUXrnpXT0hhu9BUXOWgrpGbW7NVJ1QDNvFS83MSWWQVmpCeNYsVWMBmTkNmpz9YNulCO8AWDh2dNcoRUds7YrNZZbK/eq2LfCP6RnzeJ7beZmMhCZSRkGASAOdBHpNlu+7FSgVoQGFfGf/JqYydvs1lxkWaWCNqgQP8qmFo3prSMvMulRBUVJIA0I984Jum6ULCytJAThArmTV+lecbzsxYkykAKCStSnJAyDZDoawdedmCpoUTiQA+EZOKl+mUdUOHVs55T3SPN7X2dmy1JBw+JRFNAPxGlIvbus4bCjwpTntVv4xY3ggzZjZZDmpyW8oNsd0JSn4mJybX5xouNJ6Jy1sqlyU4FUBSzJfLa5S1XjH3nduEd5Lco1/hO/+E6HlG+SlXdmWpDFWrAthJDbQMjvpFf/AMZ3Z8agBUUD4v4SDpR4JQsSlR5+gQ9JAziyvm7O58STjSTv8L5A7eMVGPdHNJNOmadkhXHFqBYVYv8ATnHEZ74dic6DYBENWS1Yx3NNsPwl4lEhTO1N0cSd0TgLEiMxhvf1hHNzDwnVnh+Jy6qwsCcSJJf9Yf7pCXhI1hhGQeJ8dE40SEGnX3sjhdquI7L5Di8GS1oYgu40ekNoKK4jUPCSTrBM2aj8IevDSIZyGLMR+sSTQ1SyKV84USZ5kjqcqQoKK/6e4K7bWVACQDT8KRQfpDP/AJzKP7uVMWeQHUx5gCKb9kP+1qFArDwz5HMcY3tm2Rd9o74mTl/fFgC6UBTJT9TvipmWhPAbiNR1OZgMKcuXJ1JqepjhQxqCDwgomxtoXU4Xy0MCTAWz/TPqYtLONKAHWLezWSxoSCtSlHOjsOkKqGo2ZixXdMUMTMmrcctdYm/48AOSCp/Zi/mWlDtLSw2qJOcD22wS0oExU9KlHJKdPWBlYoBNmJHhFWAirtNmWC6v16ZwRPmrYEFhseA5kw1BPM5wJD1Q1E0ja2sW903bPmKSQlSUAgkqdIIzo+fLbHp/Y/snZpcmTNUhEycATjILOSSKEsSnIFtHo8XNtuGVNJK8WbsC2+sapRT2K2ZezSjhGQbV68YS54SUpBGGhJBd6xY3r2TSfEiZMSwPhxAgk5EuHd98ZezXdNSv7wJLVdJJFONc9ojpjLWjIKvFLOpAKmFU6hqnDo9IcVrUWCwkpoMPjLgV+HfpuiC2WwN15mtIrLlnLtExVBLloJSSgMHDgpBep9Ibdiqi7s+HESU+LXFm43PTnHbysSpsleE4VBLpO/TTjWCUykSkgIBqdwfr73QydbCGcAIU41d6cobEeT3hPmvhm4nGhNOQFICSeA3xsu0V3d4hqY0VSraCfT0jDrKkkoIIINQdo9c45OSOLNYytBSyPZL9I7Kb2Xiw7LXFMti1JSpKEoDqUQ4fJmcPtqQzcAdMnsnKlnAtaZhzxJOED+kHrCjxtg5JGUlTdCS3GJld2KgKB3wfM7NspQxqASSMWHE7E6OG0POA7xusy094mZ3iXYkpKSHyoSaUzgfG1sFNAS1g115ekRKJhY+fOGCZEC7Jg2Rr7zhu7KuyH9ycOLEmtMw+lWfJ3HKIx1OkJqiRwVshwSMyYYU9I5hhgTIs7mhz+WscXIIOcMcw5Kt59fWJaFRzu9xjkdxvlWFCxHRub4u6RKSyFY1ZafKM8ZChWj7Nm6CFz2z865RxM7VucUi3TJLMVBgNdYtbFdJWfGsCj1bTNorLHLUo0BI3B3glEqcp28O5Ofv5wmUi2tEiyyVOpeQGjl2r1OmjxU27tAgghEunTyirVJepepzYkQPNs+j7eA374dBl9E652LOj7KRCuWAKGGBBbb84kkSlKOTN/rKKF2RKERqGbhzB0yxkZ/If7iAJfTKBDo95uSWE2eUE1ZCa7aCvPPnBy1gMCWJoIp+xttE2xyVDNKQhXFHh8wAeBEXQEW+xkNpnJAOLQP75xk7Q1VaGkau12YLDEfXg8YC/7DgBSVUeoGZL5V90jTjf0RJFPdtlVNnHVKPibLYODkeRi7M3CSmjFywow0Lb840PYy6RKswxBlTTjVwySOleZhltsKUrWvAkswAIfNtuwP1jSDV0RMqbGnEupdJS2/N34Z+UNvKxpyBY+XHnEEhX3iz8IBfdu97oJt0wYQp6uxB97Y00Z2Zi9Jawg0fzjLSboE+1YVqMtIQVKJFSEkUD6l890bCdaAFmrfOKy+1hOFYABLp5Egqy2kDpGUqvZaT9B0mzSBKwSiqWhJOLQrOeZ1qOD8oHstnMpVDiBI18zvg/sspDmVPSMKlFaMWT6gNq0WHaexWSTLEyWCFl2CScOqSS+oKhrnDWiXszs+cMYwP4RhUddgU+4kdYGt0wFDqDBQqz+kS2Cazc302/pFJb7eSsirAMToM3PHTnCk9Cop5qWJG8tDcWh6xDaZ/iIjsibHI2ahDbMvPdSJUo95RAgvE6ZpEAaHKRsjgy2wsUcAG+CxHTHVijtnHQBHDLchnrpCENxjUjzhQ77OrQP1hQiy2Fd2g9H3QTZgkllEAav74QdZLAFh8JbUx232aUnwpcqgsqiL7aEeFNfeUF2K9ZKUHEnxF3bTqaaxT4GAYAVzOvGISklVX9+8oKDIJtM9KqpBCcw+fvWB3JBf8A3wgkkAVNNkCqUTURQiFSDvDQXZ5pTQJzz2nnDJVjWs0biTQfXOLBVhlS0upbq3UgbKSZ2W0yijhER2qWhNEEHzhiJ6Rkl+NYamc6qgMNBCKN7+zG1kJmyiPESFpcsDTCR5D2I3MlZIcpKTsLfLSPN+z1uwKBwEgVxMze/nG0u7tAiYrAUlJ0JyJ2bopTT0OUH2i3U+kUYsAmzSZgZjiKfTiIMve+JdnT4i6j8KRUnkKtGest8TcM1S0KQThKSQa1IIqSQMouL3QqdWaa03ghHhzVsFT+kYi8rymKKlqUoAKLflYZDfzghN4BBcB0qzba5HLN4r5qUzSVMyQCyeTufNo3hFejCT+xtjm4kuaO6i+pow6V5b4jtdqKiNXcdaA+UQ2+aXagAoeQAb58xAMu2AKNciz0O9/OLZLVIHtExJWMRbfGZ7TXiEzsCTm7cAw+flFrfNoAnLAZsRZsmzHk0ee9pJq/tAU9QARsqTHLJvI0VYm5uy+QpKUqUUqSxHL36wr/AL8TMmtLOIvUnI5ZdPOMPY7djWMQwtmHbFlR4vyqUQJksJYFlOplOdM8qUVk9IcZp6Ioup67QEVlhAYkklnHMtFLOWo+EFyrxKbfVn4ZwRNtctaUrxMtiFPirsqdN7wDabxxoMuUkgGilbW2HeYlytGkaj+leC6i22CpaTDpFlIGUEIl7ozRJ1IyiVCxHAmsPwwwOFUIKGsSYR7MNU0IRMjAxcsoCg0O0boHmHfvjqURIUNvgAgf3X6x2Jk4d/SFCoDVIvOjVYbqCJEWlKg6l18zFPM191iOTNVnkRs021go0s0M5MpIxEddvzimn2ok0DDOGqtD6kjf56mFKDqDB4AsUthUiumscQlaiyUvuavpF7d90GaxWyUneNG0jRWa02SQkh65bzx3QWUomImWec7EYdooPKByirqcluOW+NDelplMSkgqVoKtzij7lwTp5wIGqIFT9AKawRZ0uKUJMBzKaQZZ5gGdflDY0XthSQlysPxgiT2jEhmSFEcDXbGdmrCqgkdeEDTARURNWXnRqp3b2Z4mQgKORbxDb4jAV0XqqauZ3ivwjbtfnlGYKg1QX95CCLoP3ifEwJz8/lFx07Jcm1Ru5nhAQDRQcHjn5AjnEwtUlAAUoIAJZIFMmJdtlNYlu2ySDL76cFEJdICTm+u1xofoIyvai0EOtDqlmgU3wk0ZQ/AfrR47FJrZy4ptJlVe17oK1YTidR4ZnJ4pLVeCiWfCN0DWlXvSHWCUFqxKIwgjPI9N8YuTk6NeRodZBjWSotsc9YzF5KxzVKBcOw4Cgi6vW0gHAhsRzb8I2cTAMiyNWM5/RCdgsuygtSCpViEGypMEJlDMRCRVAiLEnY8Gps4GUOKYTbYYDRDwmEFCEd0AhYqQ0whWEB/uEB1I3w5KqxwgbekLDCYgly2UQqIORjh2PHAYBnFZ0YDi/wAoUdpCgsdFshLZtz8hCCIkKXrHFvwgGRtoKVixsNpQnMA7jWBpdmd8+MOXZ2oSB5mAa0WE68FrBckDYKP00gFcoH6fWIkkDIuBlRniGfOOb+9YEhtkpDNHS4riMDlbh3yjkpOpBrvhis6pJUci0OMkisHWeSpTCNDJ7MLUnEeOyFZajZlkSyrcNsSfZ1H+WDbfJTLUEip6ZemUE2WUFEAnCjU5wWPEqJtjGSc4Dtae7OExsFIkpfTiz/pGPvSaFKIG2BMJKg6R2jWGfQvSgUdpA14RD2gvBEyWU96UkkKICQyiMkkO7VNXzisQHhKGTiNMmlVmLgm7KC2lS2CHoXKsuX6wRZpa0pwgsNz+xFmojQQ0CtYlBiCSLGBpEybPBDQ0wDIwiHKQ8KFigEcAjssUI0hER2Wh4QDMNd0OVLh3dl22Z/SHFehzgAjQiOq6ecdQvdEiUPCAFJjpU0TTLPESkwhCFYclO6J5KNRBYs4MA0ivMs7I7BeAijGFAOg6XrDT8Q4fWFChjLF6NugSccufyhQoRQLaT76xCn35woUMgnApBAhQoZRfdl0gzA4fjGvvlREssWppHYUQzePR5zaS6iTWo9YLmUlUhQoZKKVCyTUk1gCfkfe2FCijNjJcOVn72GFChkkS8xHAKQoUAiQxGo0jsKExkSzSHJhQoEJkyRSJ0CnL6woUA0SO5JNScyakwFaPiPCFCiQl0NT9IcDnChQ2SiRRpygcxyFEg+x1nOcWllNIUKAcQ4JGyFChQij/2Q==" class="img-thumbnail">
                  </div>
                  <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Reporte Operario</label>
                      <textarea name="name" readonly rows="4" cols="40" class="form-control">Se realizo la recoleccion del todo el material de residuo y se procedio a limpieza y arrehlo de zonas verdes
                       </textarea>
                  </div>

                  <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Observaciones</label>
                      <textarea name="name" rows="4" cols="40" class="form-control"></textarea>
                  </div>
                  <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Estado</label>
                      <select class="form-select mb-3" readonly aria-label="Default select example">
                          <option value="1" selected>Abierta</option>
                          <option value="2">No Realizada</option>
                          <option value="3">En Proceso</option>
                          <option value="4">Cancelada</option>
                          <option value="5">Finalizada</option>
                      </select>
                  </div>
                  <br><br>
                  <button type="button" class="btn btn-primary">Imprimir Reporte</button>
                  <button type="submit" class="btn btn-warning">Actualizar Datos</button>

                </div>
              </div>
               <!--
                <div class="col-sm-12 col-xl-6">
                    <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Select</h6>
                        <select class="form-select form-select-sm mb-3" aria-label=".form-select-sm example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <select class="form-select mb-3" aria-label="Default select example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <select class="form-select" multiple aria-label="multiple select example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                </div>-->
            </div>
        </div>





    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
                    Software para gestion de tareas Limperu</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
