<?php
  require "../../class/db/clsController.php";
  $obj_cnsc = new clsCnsc();
  if ($obj_cnsc->editarAsignacion(
    $_POST["inputId"],$_POST["inputFecha"],
    $_POST["inputTitulo"],$_POST["inputDescripcion"],
    $_POST["slcoperario"],$_POST["slczona"], $_POST["slcestado"]
  )) {
    echo "err:ok";
  }
?>
