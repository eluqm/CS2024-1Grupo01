<?php
session_start();

?>
    <!-- Navbar Start -->
  <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
            <!--<div class="nav-item dropdown">
                 <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa fa-bell me-lg-2"></i>
                    <span class="d-none d-lg-inline-flex">Notificaciones</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
                </div>
            </div>-->
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo $_SESSION['nombre'].' '.$_SESSION['apellido']; ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <!--<a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>-->
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->



<script type="text/javascript">
$("#salir").click(function(){
  swal({
       title: "Cerrar Sesion",
       text: "Realmente deseas salir de la sesion actual ?",
       type: "warning",
       showCancelButton: true,
       confirmButtonColor: "#034b7b",
       confirmButtonText: "Aceptar",
       cancelButtonText: "Cancelar",
       closeOnConfirm: false,
       closeOnCancel: false
      },
      function(isConfirm){
       if (isConfirm) {
         $.ajax({
             url:'pages/admin/logout.php',
             type:'post',
             success:function(response){
               window.location="index.php";
             }
         });
       } else {
          swal.close();
       }
    });
});
</script>







        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-sm-6 col-xl12">
                    <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Formulario Agregar Nuevo Asignacion</h6>
                        <form id="AddFormAsignacion">
                          <div class="mb-3">
                              <label for="exampleInputPassword1" class="form-label">Fecha</label>
                              <input type="text" class="form-control" value="<?php echo date("Y-m-d H:i:s");  ?>"
                              id="inputFecha" name="inputFecha">
                          </div>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Titulo</label>
                                <input type="text" class="form-control" id="inputTitulo" name="inputTitulo"
                                    aria-describedby="emailHelp">
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Descripcion</label>
                                <textarea  rows="8" cols="80" class="form-control"
                                id="inputDescripcion" name="inputDescripcion"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Operario</label>
                                <select class="form-select mb-3"  id="slcoperario" name="slcoperario">
                                  <?php
                                    require "../../class/db/clsController.php";
                                    $obj_cnsc = new clsCnsc();
                                    $resultado_cnsc = $obj_cnsc->ConsultarOperario();
                                     if(mysqli_num_rows($resultado_cnsc)>0){
                                       $cont = 0;
                                          while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                                           $cont++;
                                          ?>
                                          <option value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['nombre'].' '.$listar_repuesto['apellido']; ?></option>
                                         <?php
                                          }
                                        }else{
                                         ?>
                                         <option value="">No hay Operario</option>
                                       <?php
                                        }
                                     ?>
                              </select>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Zona</label>
                                <select class="form-select mb-3"  id="slczona" name="slczona">
                                  <?php
                                    $resultado_cnsc = $obj_cnsc->ConsultarZona();
                                     if(mysqli_num_rows($resultado_cnsc)>0){
                                       $cont = 0;
                                          while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                                           $cont++;
                                          ?>
                                          <option value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['zona']; ?></option>
                                         <?php
                                          }
                                        }else{
                                         ?>
                                         <option value="">No hay Zona</option>
                                       <?php
                                        }
                                     ?>
                              </select>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Estado</label>
                                <select class="form-select mb-3"  id="slcestado" name="slcestado">
                                  <?php
                                    $resultado_cnsc = $obj_cnsc->ConsultarEstado();
                                     if(mysqli_num_rows($resultado_cnsc)>0){
                                       $cont = 0;
                                          while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                                           $cont++;
                                          ?>
                                          <option value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['estado']; ?></option>
                                         <?php
                                          }
                                        }else{
                                         ?>
                                         <option value="">No hay Zona</option>
                                       <?php
                                        }
                                     ?>
                              </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Guardar Datos</button>
                        </form>
                    </div>
                </div>


               <!--
                <div class="col-sm-12 col-xl-6">
                    <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Select</h6>
                        <select class="form-select form-select-sm mb-3" aria-label=".form-select-sm example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <select class="form-select mb-3" aria-label="Default select example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <select class="form-select" multiple aria-label="multiple select example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                </div>-->

            </div>
        </div>

        <script type="text/javascript">
        $("#AddFormAsignacion").validate({ debug: true,
          rules:{
            inputFecha:{required: true},
            inputTitulo:{required: true},
            inputDescripcion:{required: true},
            slcoperario:{required: true},
            slczona:{required: true},
            slcestado:{required: true}
          },
          messages:{
            inputFecha:{required: "<span class='label label-danger'>Ingrese un Fecha</span>"},
            inputTitulo:{required: "<span class='label label-danger'>Ingrese un Titulo</span>"},
            inputDescripcion:{required: "<span class='label label-danger'>Ingrese una Descripcion</span>"},
            slcoperario:{required: "<span class='label label-danger'>Seleccione un operario</span>"},
            slczona:{required: "<span class='label label-danger'>Seleccione una zona</span>"},
            slcestado:{required: "<span class='label label-danger'>Seleccione un estado</span>"}
          },
          submitHandler: function(form){
            guardarForm("pages/asignacion/crearAsignacion.php", "AddFormAsignacion", function(resultado){
            if (resultado == "err:ok") {
                funcionajax("pages/asignacion/index.php","container","");
              }
            });
            }
          });
        </script>





    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
                    Software para gestion de tareas Limperu</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
