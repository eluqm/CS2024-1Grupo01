<?php
  session_start();

  header("Cache-Control: no-store, no-cache, must-revalidate");
  require "../../class/db/clsController.php";
  $obj_cnsc = new clsCnsc();
  $resultado = $obj_cnsc->ConsultarIdAsignacion($_POST['id']);
  $listar = mysqli_fetch_assoc($resultado);
?>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">
        <!--    <div class="nav-item dropdown">
                 <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa fa-bell me-lg-2"></i>
                    <span class="d-none d-lg-inline-flex">Notificaciones</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item text-center">No hay notificaciones</a>
                </div>
            </div>-->
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="img/photo1.png" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo $_SESSION['nombre'].' '.$_SESSION['apellido']; ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <!--<a id="profile" href="javascript:void(0);" class="dropdown-item">Mi Perfil</a>-->
                    <a id="salir" href="javascript:void(0);" class="dropdown-item">Cerrar Sesiòn</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->



<script type="text/javascript">
$("#salir").click(function(){
  swal({
       title: "Cerrar Sesion",
       text: "Realmente deseas salir de la sesion actual ?",
       type: "warning",
       showCancelButton: true,
       confirmButtonColor: "#034b7b",
       confirmButtonText: "Aceptar",
       cancelButtonText: "Cancelar",
       closeOnConfirm: false,
       closeOnCancel: false
      },
      function(isConfirm){
       if (isConfirm) {
         $.ajax({
             url:'pages/admin/logout.php',
             type:'post',
             success:function(response){
               window.location="index.php";
             }
         });
       } else {
          swal.close();
       }
    });
});
</script>






        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-sm-6 col-xl12">
                    <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Formulario Editar Asignacion</h6>
                        <form id="EditarFormAsignacion">
                          <div class="mb-3" style="display:none;">
                              <label for="exampleInputPassword1" class="form-label">Id</label>
                              <input type="text" class="form-control" value="<?php echo  $listar['id']; ?>" id="inputId" name="inputId">
                          </div>
                          <div class="mb-3">
                              <label for="exampleInputPassword1" class="form-label">Fecha</label>
                              <input type="text" class="form-control" value="<?php echo date("Y-m-d H:i:s");  ?>" id="inputFecha" name="inputFecha">
                          </div>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Titulo</label>
                                <input type="text" class="form-control" id="inputTitulo" name="inputTitulo"
                                    aria-describedby="emailHelp" value="<?php echo $listar['titulo']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Descripcion</label>
                                <textarea name="inputDescripcion" id="inputDescripcion" rows="4" cols="40" class="form-control"> <?php echo $listar['descripcion']; ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Operario</label>
                                <select class="form-select mb-3"  id="slcoperario" name="slcoperario">
                                  <?php
                                    $resultado_cnsc = $obj_cnsc->ConsultarOperario();
                                     if(mysqli_num_rows($resultado_cnsc)>0){
                                       $cont = 0;
                                          while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                                           $cont++;
                                            if($listar['fkoperario'] == $listar_repuesto['id']){
                                            ?>
                                            <option selected value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['nombre'].' '.$listar_repuesto['apellido']; ?></option>
                                           <?php
                                           }else{
                                            ?>
                                            <option value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['nombre'].' '.$listar_repuesto['apellido']; ?></option>
                                            <?php
                                           }
                                          }
                                        }else{
                                         ?>
                                         <option value="">No hay Operario</option>
                                       <?php
                                        }
                                     ?>
                              </select>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Zona</label>
                                <select class="form-select mb-3"  id="slczona" name="slczona">
                                  <?php
                                    $resultado_cnsc = $obj_cnsc->ConsultarZona();
                                     if(mysqli_num_rows($resultado_cnsc)>0){
                                       $cont = 0;
                                          while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                                           $cont++;
                                           if($listar['fkzona'] == $listar_repuesto['id']){
                                          ?>
                                           <option selected value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['zona']; ?></option>
                                         <?php
                                           }else{
                                            ?>
                                            <option value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['zona']; ?></option>
                                            <?php
                                           }
                                          }
                                        }else{
                                         ?>
                                         <option value="">No hay Zona</option>
                                       <?php
                                        }
                                     ?>
                              </select>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Estado</label>
                                <select class="form-select mb-3"  id="slcestado" name="slcestado">
                                  <?php
                                    $resultado_cnsc = $obj_cnsc->ConsultarEstado();
                                     if(mysqli_num_rows($resultado_cnsc)>0){
                                       $cont = 0;
                                          while ($listar_repuesto = mysqli_fetch_assoc($resultado_cnsc)) {;
                                           $cont++;
                                           if($listar['fkestado'] == $listar_repuesto['id']){
                                          ?>
                                          <option selected value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['estado']; ?></option>
                                           <?php
                                            }else{
                                            ?>
                                            <option  value="<?php echo $listar_repuesto['id']; ?>"><?php echo $listar_repuesto['estado']; ?></option>
                                            <?php
                                           }
                                          }
                                        }else{
                                         ?>
                                         <option value="">No hay Zona</option>
                                       <?php
                                        }
                                     ?>
                              </select>
                            </div>
                            <button type="submit" class="btn btn-warning">Actualizar Datos</button>
                          </form>
                      </div>
                </div>

          <script type="text/javascript">
         $("#EditarFormAsignacion").validate({ debug: true,
           rules:{
             inputFecha:{required: true},
             inputTitulo:{required: true},
             inputDescripcion:{required: true},
             slcoperario:{required: true},
             slczona:{required: true},
             slcestado:{required: true}
           },
           messages:{
             inputFecha:{required: "<span class='label label-danger'>Ingrese un Fecha</span>"},
             inputTitulo:{required: "<span class='label label-danger'>Ingrese un Titulo</span>"},
             inputDescripcion:{required: "<span class='label label-danger'>Ingrese una Descripcion</span>"},
             slcoperario:{required: "<span class='label label-danger'>Seleccione un operario</span>"},
             slczona:{required: "<span class='label label-danger'>Seleccione una zona</span>"},
             slcestado:{required: "<span class='label label-danger'>Seleccione un estado</span>"}
           },
           submitHandler: function(form){
             guardarForm("pages/asignacion/editarAsignacion.php", "EditarFormAsignacion", function(resultado){
             if (resultado == "err:ok") {
                 funcionajax("pages/asignacion/index.php","container","");
               }
             });
             }
           });
         </script>





                <div class="col-sm-6 col-xl12">
                    <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Informe Operario</h6>
                          <div class="mb-3">
                              <label for="exampleInputPassword1" class="form-label">Evidencia</label>
                              <br>

                              <img src="<?php if($listar["foto"] != "" && $listar["foto"] != "null"){ echo "api/".$listar["foto"];}else{ echo "images/default-50x50.gif";} ?>"    id="image" style="/* width: 100px; */height: 160px;" alt="Product Image">

                          </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Reporte</label>
                                <textarea  readonly  name="name" rows="4" cols="40" class="form-control"> <?php echo $listar['reporte']; ?></textarea>
                            </div>

                      </div>
                </div>
            </div>
        </div>


    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-end">
                    Software para gestion de tareas Limperu</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
