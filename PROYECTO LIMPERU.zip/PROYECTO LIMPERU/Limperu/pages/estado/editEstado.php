<?php
  require "../../class/db/clsController.php";
  $obj_cnsc = new clsCnsc();
  if ($obj_cnsc->EditarEstado(
    $_POST["idestado"],
    $_POST["estado"])) {
    echo "err:ok";
  }
?>
