<?php
  require "../../class/db/clsController.php";
  $obj_cnsc = new clsCnsc();
  if ($obj_cnsc->CrearEstado($_POST["estado"] )) {
    echo "err:ok";
  }
?>
