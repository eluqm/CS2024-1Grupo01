<?php
require_once("dbClass.php");
ini_set('display_errors',1);

class clsCnsc{
  public $id, $link, $estado;
  public $conexion;

  public function __construct(){
    $this->conexion = new dbConect();
  }
  
  
  public function CantidadMesAsignacion($id){
    $resultado = $this->conexion->ejecutarQuery("SELECT count(*) AS id FROM `labor` WHERE MONTH(fecha) = $id ");
    return $resultado;
  }
  
  
  
   public function EditarZona($id ,$nombre, $marcacion, $estado){

      date_default_timezone_set('America/Mexico_City');
      $now = date('Y-m-d H:i:s');

      $this->id = $id;
      $this->nombre = $nombre;
      $this->marcacion = $marcacion;
      $this->estado = $estado;

      $resultado = $this->conexion->ejecutarQuery("UPDATE zona AS z SET
      z.zona = '{$this->nombre}',
      z.estado = '{$this->estado}'
      WHERE z.id = '{$this->id}' ");

      return true;
    }

  
  
  
  public function EditarOperador($id, $identificacion, $nombre,
    $apellido, $estado, $correo, $telefono,
    $usuario, $password
  ){
      $this->id = $id;
      $this->identificacion = $identificacion;
      $this->nombre = $nombre;
      $this->apellido = $apellido;
      $this->estado = $estado;
      $this->correo = $correo;
      $this->telefono = $telefono;
      $this->usuario = $usuario;
      $this->password = $password;

      $resultado = $this->conexion->ejecutarQuery("UPDATE operario AS o SET
      o.identificacion = '{$this->identificacion}',
      o.nombre = '{$this->nombre}',
      o.apellido = '{$this->apellido}',
      o.correo = '{$this->correo}',
      o.telefono = '{$this->telefono}',
      o.usuario = '{$this->usuario}',
      o.estado = '{$this->estado}',
      o.clave = '{$this->password}'
      WHERE o.id = '{$this->id}' ");

      return true;
    }

  

    public function editarAsignacion($id, $fecha, $titulo, $descripcion, $operario, $zona, $estado){
      $this->id = $id;
      $this->fecha = $fecha;
      $this->titulo = $titulo;
      $this->descripcion = $descripcion;
      $this->operario = $operario;
      $this->zona = $zona;
      $this->estado = $estado;

      $resultado = $this->conexion->ejecutarQuery("UPDATE labor AS l SET
      l.titulo = '{$this->titulo}',
      l.descripcion = '{$this->descripcion}',
      l.fkzona = '{$this->zona}',
      l.fkoperario = '{$this->operario}',
      l.fkestado = '{$this->estado}'
      WHERE l.id = '{$this->id}' ");

      return true;
    }


  public function ConsultarCantidadAsignacion(){
    $resultado = $this->conexion->ejecutarQuery("SELECT COUNT(*) AS cantidad FROM `labor`");
    return $resultado;
  }
  public function ConsultarCantidadZonas(){
    $resultado = $this->conexion->ejecutarQuery("SELECT COUNT(*) AS cantidad FROM `zona`");
    return $resultado;
  }
  public function ConsultarCantidadOperadores(){
    $resultado = $this->conexion->ejecutarQuery("SELECT COUNT(*) AS cantidad FROM `operario` ");
    return $resultado;
  }
  public function ConsultarCantidadPendiientes(){
    $resultado = $this->conexion->ejecutarQuery("SELECT COUNT(*) AS cantidad FROM `labor` AS l INNER JOIN `estado` AS e ON l.fkestado = e.id WHERE e.estado != 'REPORTE' AND e.estado != 'FINALIZADA'");
    return $resultado;
  }

  public function ConsultarIdAsignacion($id){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM labor WHERE  id = $id ");
    return $resultado;
  }


  public function ConsultarIdZona($id){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM zona WHERE  id = $id ");
    return $resultado;
  }


  public function ConsultarIdAdmin($id){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM administrador WHERE  id = $id ");
    return $resultado;
  }



  public function ConsultarIdEstado($id){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM estado WHERE  id = $id ");
    return $resultado;
  }

  public function ConsultarIdOperarios($id){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM operario WHERE  id = $id ");
    return $resultado;
  }


  public function EliminarEstado($id){
    $this->id = $id;
    $resultado = $this->conexion->ejecutarQuery("DELETE FROM estado WHERE id = '{$this->id}'");
    return true;
  }

  public function EliminarZona($id){
    $this->id = $id;

    $resultado = $this->conexion->ejecutarQuery("DELETE FROM coordenadas WHERE fkzona = '{$this->id}'");

    $resultado = $this->conexion->ejecutarQuery("DELETE FROM zona WHERE id = '{$this->id}'");
    return true;
  }


  public function EliminarOperador($id){
    $this->id = $id;
    $resultado = $this->conexion->ejecutarQuery("DELETE FROM operario WHERE id = '{$this->id}'");
    return true;
  }

  public function ConsultarAsignacion(){
    $resultado = $this->conexion->ejecutarQuery("SELECT l.id, l.fecha, l.titulo, l.descripcion,
        (SELECT zona FROM zona WHERE id = l.fkzona) AS zona,
        (SELECT CONCAT(nombre,' ',apellido) FROM operario WHERE id = l.fkoperario) AS operario,
        (SELECT estado FROM estado WHERE id = l.fkestado) AS estado
       FROM labor AS l");
    return $resultado;
  }


  public function ConsultarAdmin(){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM administrador");
    return $resultado;
  }

  public function ConsultarCoordenadas($id){
    $cadena = "";
    $result = $this->conexion->ejecutarQuery("SELECT * FROM coordenadas WHERE fkzona = '$id' ");
     if(mysqli_num_rows($result)>0){
          while ($listar = mysqli_fetch_assoc($result)) {
            $cadena .=  "(".$listar['latitud'].','.$listar['longitud']."),";
          }
      }
      return $cadena;
  }

  public function ConsultarEstado(){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM estado");
    return $resultado;
  }

  public function CrearEstado($estado){
     $this->estado = $estado;

     $resultado = $this->conexion->ejecutarQuery("INSERT INTO estado(
         estado)
       VALUES ('{$this->estado}'
          );");
     return true;
   }



   public function CrearAsignacion($fecha, $titulo,  $descripcion, $operario, $zona, $estado){
      $this->fecha = $fecha;
      $this->titulo = $titulo;
      $this->descripcion = $descripcion;
      $this->operario = $operario;
      $this->zona = $zona;
      $this->estado = $estado;

      date_default_timezone_set('America/Mexico_City');
      $now = date('Y-m-d H:i:s');

      $resultado = $this->conexion->ejecutarQuery("INSERT INTO labor(
         fecha, titulo, descripcion, fkzona, fkoperario , fkestado)
        VALUES ('{$this->fecha}','{$this->titulo}',
          '{$this->descripcion}',   '{$this->zona}',
            '{$this->operario}',
            '{$this->estado}'
          );");
      return true;
    }







    public function EditarEstado($idEstado, $estado){
      $this->idEstado = $idEstado;
      $this->estado = $estado;

      $resultado = $this->conexion->ejecutarQuery("UPDATE estado AS e SET
      e.estado = '{$this->estado}'
      WHERE e.id = '{$this->idEstado}' ");

      return true;
    }


  public function CrearZona($nombre, $marcacion,  $estado){
     $this->nombre = $nombre;
     $this->marcacion = $marcacion;
     $this->estado = $estado;

     date_default_timezone_set('America/Mexico_City');
     $now = date('Y-m-d H:i:s');

     $por = explode("),", $marcacion);
     $cant = count($por);

     $resultado = $this->conexion->ejecutarQuery("INSERT INTO zona(
        zona,  estado)
       VALUES ('{$this->nombre}','{$this->estado}');");

     $idZona = self::MaxZona();

     for ($i=0; $i < $cant; $i++) {
       $cadena = str_replace("(","",$por[$i]);
       $por1 = explode(",", $cadena);
       $porLatitud = $por1[0];
       $porLongitud = $por1[1];

       $por2x = explode(")", $porLatitud);
       $por2s = explode(")", $porLongitud);
       $porLatitud2x = $por2x[0];
       $porLongitud2s = $por2s[0];


       $resultado = $this->conexion->ejecutarQuery("INSERT INTO coordenadas(
          latitud, longitud, fkzona)
        VALUES ('{$porLatitud2x}','{$porLongitud2s}','{$idZona}');");

     }

     return true;
   }






  public function ConsultarZona(){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM zona");
    return $resultado;
  }


    public function ConsultarOperario(){
      $resultado = $this->conexion->ejecutarQuery("SELECT * FROM operario");
      return $resultado;
    }


  public function ValidarUser($nombre, $password){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM administrador WHERE usuario = '{$nombre}'");
    return $resultado;
  }

  public function hashSSHA($password) {
      $salt = sha1(rand());
      $salt = substr($salt, 0, 10);
      $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
      $hash = array("salt" => $salt, "encrypted" => $encrypted);
      return $hash;
  }
  public function checkhashSSHA($salt, $password) {
      $hash = base64_encode(sha1($password . $salt, true) . $salt);
      return $hash;
  }




    public function CrearOperador($identificacion, $nombre,  $apellido, $estado , $correo, $telefono ,$usuario, $password){
     $this->identificacion = $identificacion;
     $this->nombre = $nombre;
     $this->apellido = $apellido;
     $this->estado = $estado;
     $this->correo = $correo;
     $this->telefono = $telefono;
     $this->usuario = $usuario;
     $this->password = $password;

     date_default_timezone_set('America/Mexico_City');
     $now = date('Y-m-d H:i:s');


     $resultado = $this->conexion->ejecutarQuery("INSERT INTO operario(
       identificacion,nombre, apellido,
       correo, telefono, usuario, estado,  clave)
       VALUES ('{$this->identificacion}','{$this->nombre}',
         '{$this->apellido}', '{$this->correo}','{$this->telefono}',
          '{$this->usuario}', '{$this->estado}', '{$this->password}'
          );");
     return true;
   }



  public function EliminarAdmin($id){
    $this->id = $id;
    $resultado = $this->conexion->ejecutarQuery("DELETE FROM administrador WHERE id = '{$this->id}'");
    return true;
  }






  public function CrearAdmin($nombre, $apellido, $correo, $usuario, $password, $estado){
     $this->nombre = $nombre;
     $this->apellido = $apellido;
     $this->correo = $correo;
     $this->usuario = $usuario;
     $this->password = $password;
     $this->estado = $estado;

     date_default_timezone_set('America/Mexico_City');
     $now = date('Y-m-d H:i:s');

     $resultado = $this->conexion->ejecutarQuery("INSERT INTO administrador(nombre, correo, apellido, usuario, estado, clave)
     VALUES ('{$this->nombre}','{$this->correo}', '{$this->apellido}', '{$this->usuario}','{$this->estado}','{$this->password}');");

     return true;
   }




   public function MaxZona(){
       $resultado = $this->conexion->ejecutarQuery("SELECT MAX(id) AS id FROM zona");
       $valor = mysqli_fetch_assoc($resultado);
       return $valor['id'];
  }





}
?>
