<?php 
header("Location: ../suite.php");
?>