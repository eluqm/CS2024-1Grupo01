<?php
require_once("dbClass.php");
ini_set('display_errors',1);

class clsCnsc{
  public $id, $link, $estado;
  public $conexion;

  public function __construct(){
    $this->conexion = new dbConect();
  }


  public function ConsultarIdOperarios($id){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM operario WHERE  id = $id ");
    return $resultado;
  }


  public function EliminarOperador($id){
    $this->id = $id;
    $resultado = $this->conexion->ejecutarQuery("DELETE FROM operario WHERE id = '{$this->id}'");
    return true;
  }

  public function ConsultarAdmin(){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM administrador");
    return $resultado;
  }


    public function ConsultarOperario(){
      $resultado = $this->conexion->ejecutarQuery("SELECT * FROM operario");
      return $resultado;
    }


  public function ValidarUser($nombre, $password){
    $resultado = $this->conexion->ejecutarQuery("SELECT * FROM administrador WHERE usuario = '{$nombre}'");
    $result = mysqli_fetch_assoc($resultado);
    $salt = $result['hash'];
    $encrypted_password = $result['clave'];
    $hash = self::checkhashSSHA($salt, $password);
    if ($encrypted_password == $hash) {
         $resultadox = $this->conexion->ejecutarQuery("SELECT * FROM administrador AS a WHERE a.usuario = '{$nombre}' ");
        return $resultadox;
    }else{
       return NULL;
    }
  }

  public function hashSSHA($password) {
      $salt = sha1(rand());
      $salt = substr($salt, 0, 10);
      $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
      $hash = array("salt" => $salt, "encrypted" => $encrypted);
      return $hash;
  }
  public function checkhashSSHA($salt, $password) {
      $hash = base64_encode(sha1($password . $salt, true) . $salt);
      return $hash;
  }




  public function CrearOperador($identificacion, $nombre,  $apellido, $estado , $correo, $telefono ,$usuario, $password){
     $this->identificacion = $identificacion;
     $this->nombre = $nombre;
     $this->apellido = $apellido;
     $this->estado = $estado;
     $this->correo = $correo;
     $this->telefono = $telefono;
     $this->usuario = $usuario;
     $this->password = $password;

     date_default_timezone_set('America/Mexico_City');
     $now = date('Y-m-d H:i:s');

     $hash = $this->hashSSHA($password);
     $encrypted_password = $hash["encrypted"]; // encrypted password
     $salt = $hash["salt"];

     $resultado = $this->conexion->ejecutarQuery("INSERT INTO operario(
       identificacion,nombre, apellido,
       correo, telefono, usuario, estado, hash, clave)
       VALUES ('{$this->identificacion}','{$this->nombre}',
         '{$this->apellido}', '{$this->correo}','{$this->telefono}',
          '{$this->usuario}', '{$this->estado}',  '{$salt}', '{$encrypted_password}'
          );");
     return true;
   }















  public function CrearAdmin($identificacion, $nombre,  $apellido, $direccion , $telefono, $usuario , $password, $rol){
     $this->identificacion = $identificacion;
     $this->nombre = $nombre;
     $this->apellido = $apellido;
     $this->direccion = $direccion;
     $this->telefono = $telefono;
     $this->usuario = $usuario;
     $this->password = $password;
     $this->rol = $rol;

     date_default_timezone_set('America/Mexico_City');
     $now = date('Y-m-d H:i:s');

     $hash = $this->hashSSHA($password);
     $encrypted_password = $hash["encrypted"]; // encrypted password
     $salt = $hash["salt"];

     $resultado = $this->conexion->ejecutarQuery("INSERT INTO usuario(usuario, password, hash,  rol) VALUES ('{$this->usuario}','{$encrypted_password}','{$salt}','{$this->rol}');");
     $id = self::MaxUser();

     $resultado = $this->conexion->ejecutarQuery("INSERT INTO administrador(identificacion,nombre, correo, apellido, user, telefono, estado) VALUES ('{$this->nombre}','{$this->usuario}', '{$this->apellido}', '{$id}','{$this->telefono}','Activo');");
     return true;
   }
}
?>
